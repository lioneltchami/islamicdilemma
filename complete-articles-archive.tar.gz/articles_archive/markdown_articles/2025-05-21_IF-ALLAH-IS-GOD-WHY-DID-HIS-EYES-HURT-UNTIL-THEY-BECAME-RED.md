# IF ALLAH IS GOD, WHY DID HIS EYES HURT UNTIL THEY BECAME RED?

**Publication Date:** May 21, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/05/if-allah-is-god-why-did-his-eyes-hurt.html  
**Keyword Match:** allah  
**Word Count:** 285  
**Archived:** 2025-12-19 01:05:46  
**Date Source:** content_regex

---

IF ALLAH IS GOD, WHY DID HIS EYES HURT UNTIL THEY BECAME RED?Allah (s.w) had sore eyes, and during the flood of Prophet Noah (a.s), he cried until his eyes turned red."At one time, Allah’s eyes were sore, and the angels went to see him, and that Allah shed tears because of the flood of Prophet Noah until his eyes became red (Al Milal Wannihal Vol.1 p.141).It is a great tragedy when we read evidence that:Allah has eyes like creatures.Allah cries like creatures, which is blasphemous.Allah has human-like attributes, including shedding tears.A SELF-AWARE CHRISTIAN CANNOT FOLLOW ALLAH, WHO SUFFERS EYE AILMENTS LIKE CREATURES.ALLAH HAS EYES: We believe that Allah truly has two eyes, based on His statement, Exalted is He, when He said to Noah (‘Alayhis-Salaam):"Build the Ark under Our eyes and Our inspiration."Hud – 37And the Messenger of Allah (Peace and Blessings of Allah be upon him) said:"His veil is light, and if He were to remove it, the splendor of His countenance would consume everything His sight reached."And when he was narrating about the Dajjal, he said:"The Dajjal is one-eyed, and your Lord is not one-eyed."And we believe that our eyes cannot perceive Allah.Allah says:"Vision perceives Him not, but He perceives [all] vision; and He is the Subtle, the Acquainted."Al-An’aam – 103Dear readers, you have already understood that Allah is a creature like a human being because he has eyes and, moreover, he suffered from an eye ailment.God bless you greatly.In His service,Dr. Max Shimba, a servant of Jesus Christ, our Great God and Savior.Max Shimba Ministries Org.MAX SHIMBA MINISTRIES ORG ©2015. ALL RIGHTS RESERVED.Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
