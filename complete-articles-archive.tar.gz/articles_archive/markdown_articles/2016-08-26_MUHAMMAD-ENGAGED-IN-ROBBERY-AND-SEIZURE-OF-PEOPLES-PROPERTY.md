# MUHAMMAD ENGAGED IN ROBBERY AND SEIZURE OF PEOPLE’S PROPERTY

**Publication Date:** August 26, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/12/muhammad-engaged-in-robbery-and-seizure.html  
**Keyword Match:** muslim  
**Word Count:** 175  
**Archived:** 2025-12-14 18:19:06  
**Date Source:** content_regex

---

Friday, August 26, 2016MUHAMMAD ENGAGED IN ROBBERY AND SEIZURE OF PEOPLE’S PROPERTYSurely, this behavior is not that of a prophet at all.Muhammad, along with his followers, seized the goods of caravans belonging to merchants and travelers.Bukhari, Volume 3, Book 37, Chapter 8, No. 495, p. 280 states:“When Allah made the Prophet wealthy despite the lack of victory, one-fifth of the war captives was placed in the treasury.”Sahih Muslim, Volume 2, Book 5, Chapter 401, No. 2348, p. 519 indicates that Muhammad’s family had shares in these spoils.The first known seizure of people’s property by Muslims was called the Nakha Raid. During the month in which fighting was to be suspended temporarily, his followers attacked the caravan, killing one person, taking captives, and seizing the goods. Muhammad himself led the second raid at Badr.Muhammad further increased his wealth by attacking the Jewish settlement of Khaybar. He and his loyal followers seized spoils and wives (Did Muhammad need another wife?) of the Jewish men—between 700 to 1,000—from the Banu Qurayza tribe, beheading them after they had surrendered.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
