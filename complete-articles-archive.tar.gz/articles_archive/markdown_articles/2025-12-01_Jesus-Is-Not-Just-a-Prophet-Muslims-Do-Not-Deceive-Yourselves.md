# Jesus Is Not Just a Prophet. Muslims, Do Not Deceive Yourselves!!

**Publication Date:** December 01, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/jesus-is-not-just-prophet-muslims-do.html  
**Keyword Match:** islam  
**Word Count:** 397  
**Archived:** 2026-01-19 18:21:47  
**Date Source:** content_regex

---

Jesus Is Not Just a Prophet. Muslims, Do Not Deceive Yourselves!!By Dr. Maxwell Shimba, Shimba Theological InstituteToday I went to Minneapolis for a small meeting of four people that we held inside a commercial building known as Somali Mall. It was my first time entering that building. I had the opportunity to enter a bookstore called Akmal Bookstore, which is filled with Islamic books in Arabic and Somali.I asked if there were any English books, and I was shown where they were. I saw many interesting ones and purchased one titledJesus: Prophet of Islam, written by Muhammad ‘Ata’ ur-Rahim and Ahmad Thomson.For many years I have known that in Islam, Jesus is recognized as a prominent prophet, but not as the Son of God, as we Christians know Him. Our Muslim brothers deceive themselves by claiming that Jesus is only a prophet and merely a human being like all other humans. They deny the Divinity of Jesus and His supremacy, insisting that He is equal to Adam. But what human being has ever possessed these attributes?Jesus said in John 14:13:“And whatever you ask in My Name, that I will do.”– Here, Jesus does not meanonly at that time, butNOW.– What human being can be askedanything?– What human being can doeverythingthat is asked of him?– Even if one argues that He does so by the power of God, can Muhammad, Moses, David, or anyone else be askedtodayto do even the smallest thing and actually accomplish it?…………Jesus said in Matthew 18:20:“For where two or three are gathered in My Name, I am there among them.”– What human being can beeverywhereon earth at the same time?– Is it Muhammad, Moses, or David?…………..Jesus said in Mark 28:20:“And behold, I am with you always, even to the end of the age.”– What human being can be presentat all times, until the end of the world?…………..Only Jesus has the power to prepare an eternal place for all human beings.Jesus said in John 14:2–3:“For I go to prepare a place for you… I will come again and receive you to Myself; that where I am, there you may be also.”– What human being has the ability toprepare a placefor mortal humans after they die?– Is it Muhammad or Moses?…………………It is better for you to wake up today.There isno life whatsoeveroutside of Jesus Christ.Thank You Jesus, God of heaven and earth.Dr. Maxwell ShimbaShimba Theological Institute

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
