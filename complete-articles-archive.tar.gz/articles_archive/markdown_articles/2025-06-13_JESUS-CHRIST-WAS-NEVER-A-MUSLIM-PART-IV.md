# JESUS CHRIST WAS NEVER A MUSLIM – PART IV

**Publication Date:** June 13, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/06/jesus-christ-was-never-muslim-part-iv.html  
**Keyword Match:** islam  
**Word Count:** 361  
**Archived:** 2025-12-10 06:35:54  
**Date Source:** content_regex

---

Addressing Dietary Laws, Circumcision, and the Messiah TitleBy Dr Maxwell Shimba, Shimba Theological Institute(1)Did Jesus Follow Islamic Dietary Laws?Muslim Claim:Muslims point out that Jesus didn’t eat pork and kept certain dietary restrictions, similar to Islamic halal requirements, so He must have been a Muslim.Biblical Reality:Jesus observed the dietary laws of the Torah as all devout Jews did (see Leviticus 11). Abstaining from pork and unclean foods was commanded for all Israelites long before Islam existed.Key Point:Jesus followed Jewish kosher laws, not Islamic halal laws. Kosher pre-dates halal by over a millennium.Furthermore, in Mark 7:18-19, Jesus began to reveal that it is not food but what comes from the heart that defiles a person. This shift is entirely non-Islamic.(2)Was Jesus Circumcised According to Islamic Custom?Muslim Claim:Muslims highlight that Jesus was circumcised, a practice also found in Islam.Biblical Truth:Jesus was circumcised on the eighth day (Luke 2:21), in fulfillment of the covenant God made with Abraham (Genesis 17:10-12), as all Jewish males were.Key Point:Circumcision is a sign of the Abrahamic covenant, not a marker of Islam. It is foundational to Jewish identity and predates Islam by two thousand years.(3)Is “Messiah” Just Another Term for Prophet in Islam?Muslim Claim:Islam acknowledges Jesus (Isa) as al-Masih (the Messiah), but only as a prophet, not the divine Son of God.Scriptural Reality:In the Bible, “Messiah” (Hebrew:Mashiach, Greek:Christos) means “Anointed One,” and refers to the Savior promised to Israel, not merely a prophet.Key Point:Jesus fulfilled specific Messianic prophecies (see Isaiah 9:6, Micah 5:2, Daniel 9:25-26).The New Testament presents Jesus as Son of God and Redeemer, not just a messenger (see John 1:1-14, John 20:31).The Quranic “Isa” is fundamentally different from the Jesus of the Bible, stripped of His divinity, atoning death, and resurrection.Accepting Jesus only as a prophet is to deny His true identity and mission.Summary and Final ThoughtsJesus’dietary practicesandcircumcisionwere thoroughly Jewish, rooted in the Torah, not in later Islamic law.Thetitle “Messiah”is deeply Messianic and redemptive in the Bible—far beyond the Islamic concept of a prophet.Islamic attempts to appropriate Jesusrely on retroactive claims and redefinitions that strip Him of His biblical identity and mission.Jesus is the Messiah, Son of God, and Savior—not a Muslim prophet.Shalom,Dr Maxwell ShimbaShimba Theological Institute

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
