# Muhammad Was Baptized with Much Water Just Like the Apostle Paul

**Publication Date:** May 21, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/05/muhammad-was-baptized-with-much-water.html  
**Keyword Match:** muslim  
**Word Count:** 287  
**Archived:** 2026-02-02 06:54:12  
**Date Source:** content_regex

---

Evidence HereIntroductionQuestions for Muslims:Provide a Hadith or Quranic verse stating that Muhammad was never baptized or washed of his sins with water to prove he was not baptized.If Muhammad was baptized, why do you, as a Muslim, oppose your prophet when he was washed of sins with water through baptism?Hadith EvidenceNarrated by Aisha:The Prophet (ﷺ) used to say: "O Allah, cleanse my sins with snow and cold water, and purify my heart from sins as a white garment is purified from dirt."Original Arabic:اللهم اغسل خطاياي بالمعهد الثلج والبارد كان نقي قلبي من الخطايا كنقطة الثوب الابيض من الدناس (اللهم اعمدني (اغسل) ذنوبي. وطهر قلبي من الثلج بالبرد ، وطهر قلبي من الخطيئة مثل ثوب أبيض مطهر من النجاسة. "Source:Sunan an-Nasa'i 333, Volume 1, Book 2, Hadith 334This evidence suggests that Muhammad sought purification and washing of his sins, much like the Christian concept of baptism.Further Hadith:Narrated by Abdullah b. Abu Aufa:The Messenger of Allah (ﷺ) used to say: "O Allah! Our Lord, all praise is Yours, filling the heavens and the earth and whatever You will beyond that. O Allah, cleanse my sins with snow, hail, and cold water. O Allah, cleanse my sins and errors with water as a white garment is cleansed from dirt."Original Arabic:حَدَّثَنِي مُحَمَّدُ بْنُ الْمُثَنَّى، وَابْنُ، بَشَّارٍ قَالَ ابْنُ الْمُثَنَّى حَدَّثَنَا مُحَمَّدُ بْنُ جَعْفَرٍ، حَدَّثَنَا شُعْبَةُ، عَنْ مَجْزَأَةَ بْنِ زَاهِرٍ، قَالَ سَمِعْتُ عَبْدَ اللَّهِ بْنَ أَبِي أَوْفَى، يُحَدِّثُ عَنِ النَّبِيِّ صلى الله عليه وسلم أَنَّهُ كَانَ يَقُولُ ‏ "‏ اللَّهُمَّ لَكَ الْحَمْدُ مِلْءَ السَّمَاءِ وَمِلْءَ الأَرْضِ وَمِلْءَ مَا شِئْتَ مِنْ شَىْءٍ بَعْدُ اللَّهُمَّ طَهِّرْنِي بِالثَّلْجِ وَالْبَرَدِ وَالْمَاءِ الْبَارِدِ اللَّهُمَّ طَهِّرْنِي مِنَ الذُّنُوبِ وَالْخَطَايَا كَمَا يُنَقَّى الثَّوْبُ الأَبْيَضُ مِنَ الْوَسَخِ ‏"‏ ‏.‏Source:Sahih Muslim 476c, Book 4, Hadith 231ConclusionPeace of Jesus PrevailShalom,Dr. Maxwell Shimba

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
