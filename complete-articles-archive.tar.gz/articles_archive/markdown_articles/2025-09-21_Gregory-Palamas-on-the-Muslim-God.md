# Gregory Palamas on the Muslim God

**Publication Date:** September 21, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/09/gregory-palamas-on-muslim-god.html  
**Keyword Match:** muslim  
**Word Count:** 368  
**Archived:** 2026-02-01 01:42:07  
**Date Source:** content_regex

---

Gregory Palamas on the Muslim GodSt. Gregory mentions a dialogue he had with a group of Turkish Muslims. What makes his comments rather amazing is that he affirms that both the Muslims and himself are calling upon one and the same God, even though these Turks are ignorant of the fact that this God whom they worship is inseparable from Christ:“He, rising up his hands, let out a cry and they responded even louder. He did this three times.Then those who were set to do the burying take the box up on their arms and walk further down. All the rest of them, with the Tasimanes, returned home. As I was sitting there I asked whether anyone could speak both languages that I needed. There was somebody, whom I asked to say TO THE TURKS [Muslims] on my behalf that what they had performed outside there I thought it was good, “for you addressed yourselves to God – to whom else? – for the deceased one. I wanted, however, to know what was that you exclaimed to God?” Tasimanes using the same interpreter said that he would explain: “We asked for forgiveness from God for the deceased, for his own sins committed in his soul.” Retorting myself I said, “Very well, but the judge is merciful, indeed, and dispenses mercy; and he who will come as judge of every race of men, even according to you, is Christ. You must be addressing, therefore, the prayers and the exclamations to Him. Thus you, too, invoke him as God, as we do, who believe that as an inborn Word of His he is indivisible from the Father; for there was no time when God was without reason or without the natural word.” (Source: Saint Gregory Palamas,Littera & Dialexis Patrologia Migne–PG, CL, COL. DCCCVIII)Notice how this great saint argues that the Muslims do indeed believe in the same God, and not different one. He then sets forth to prove that Jesus is indivisible from this God whom the Turks worship since is the Word of the Father. St. Gregory could not argue this way if he actually thought that the Muslim god was different from the God he professed and worshiped.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
