# WHY DIDN'T YAHYA "JOHN" IN THE QURAN BAPTIZE MUSLIMS?

**Publication Date:** May 21, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/05/why-didnt-yahya-john-in-quran-baptize.html  
**Keyword Match:** islam  
**Word Count:** 363  
**Archived:** 2025-12-22 01:08:22  
**Date Source:** content_regex

---

MUSLIMS: ACCORDING TO YOUR QURAN, WHERE DID JOHN'S BAPTISM COME FROM?When I say every day that Islam is a fabricated religion made by Muhammad, I am not joking. The John the Baptist in the Bible is not the same as the fake Yahya in the Quran in Surah Maryam, verse 7. Not at all.John in English is JohnJohn in Arabic is يوحنا (Yuhanna)John in Japanese is ジョン (Jon)John in Chinese is 約翰 (Yuēhàn)So where did the name Yahya come from for Muslims, and did this Yahya baptize people like John in the Bible, who existed 600 years before Islam? In the Arabic Bible, the name is يوحنا (Yuhanna) and not Yahya, the fake name given by Muslims. You can verify this here:Arabic BibleTo test this truth, today I ask Muslims a simple question:Matthew 21:25"The baptism of John, where was it from? From heaven or from men?" They reasoned among themselves, saying, "If we say, 'From heaven,' He will say to us, 'Why then did you not believe him?'"QUESTION:Where did the baptism of John come from?I would like Muslims to answer me with verses and not just their own words.If the baptism of "Yahya" came from the Great God, why aren’t you Muslims baptized?If it came from men, why isn’t there a verse in the Quran that rejects the baptism of "John"?If it came from men, why was Jesus baptized?If there is no verse in the Quran that talks about baptism, then "Yahya" is not the same as "يوحنا (Yuhanna)" John in the Bible, and the Yahya in the Quran is fake and was fabricated by Muhammad.The Bible says, “Or do you not know that all of us who were baptized into Christ Jesus were baptized into His death? We were therefore buried with Him through baptism into death in order that, just as Christ was raised from the dead through the glory of the Father, we too may live a new life.” (Romans 6:3-4).In Christian baptism, the act of being immersed in water symbolizes being buried with Christ. The act of coming out of the water symbolizes being resurrected with Christ.Shalom,Max Shimba, servant of Jesus Christ, the Great God and our Savior.Titus 2:13

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
