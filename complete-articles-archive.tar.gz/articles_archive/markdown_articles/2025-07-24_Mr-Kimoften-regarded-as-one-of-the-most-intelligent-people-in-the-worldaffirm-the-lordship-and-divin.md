# Mr. Kim—often regarded as one of the most intelligent people in the world—affirm the lordship and divinity of Jesus Christ

**Publication Date:** July 24, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/07/mr-kimoften-regarded-as-one-of-most.html  
**Keyword Match:** dua  
**Word Count:** 323  
**Archived:** 2026-01-19 12:33:12  
**Date Source:** content_regex

---

It is commendable that Mr. Kim, widely regarded as one of the most intelligent individuals alive, publicly affirms that Jesus Christ is God. As believers, we rejoice whenever anyone confesses Christ as Lord, whether of high or low intellect, for the gospel is the power of God unto salvation to all who believe (Romans 1:16). However, let us be clear: the divinity of Jesus Christ is not validated by human intelligence, no matter how extraordinary. Truth is not subject to IQ scores; it is grounded in divine revelation.Throughout history, many great minds have embraced the Christian faith—Augustine, Pascal, Newton, and others—not because their intellect proved Christ’s deity, but because the Spirit of God opened their hearts to the truth of the gospel. Similarly, many intellectuals have rejected Christ, for as Scripture declares, “the natural man does not receive the things of the Spirit of God, for they are foolishness to him” (1 Corinthians 2:14). The gospel transcends human reasoning; it is spiritually discerned.Mr. Kim’s testimony, while encouraging, should not be treated as evidence of Christ’s divinity, but as a witness to the reality that even the most brilliant minds are not beyond the reach of God’s grace. Jesus is not Lord because the world’s smartest man says so; He is Lord because He rose from the dead (Romans 1:4), fulfilled prophecy (Isaiah 53; Daniel 9), and is exalted at the right hand of the Father (Hebrews 1:3). His deity is a revealed truth, affirmed by Scripture, declared by the apostles, and sealed in the hearts of believers by the Holy Spirit.Let the church not be swayed by celebrity confessions or intellectual endorsements, but by the enduring truth of the Word of God. The confession that “Jesus is Lord” remains a miracle of grace, not a product of intellect. For as Jesus Himself said, “flesh and blood has not revealed this to you, but My Father who is in heaven” (Matthew 16:17).—Dr. Maxwell Shimba

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
