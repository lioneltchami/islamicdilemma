# MUHAMMAD SAYS PLANETS RISE AND RUN LIKE THE SUN AND MOON.

**Publication Date:** December 14, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/06/muhammad-says-planets-rise-and-run-like.html  
**Keyword Match:** muslim  
**Word Count:** 295  
**Archived:** 2025-12-09 06:21:55  
**Date Source:** content_regex

---

Wednesday, December 14, 2016He claims that stars are hung up like lanterns in a mosque.So what are Muhammad and the early Muslims telling us about the heavens?The Prophet [Muhammad] replied: ‘Ali, there are five stars: Jupiter (al-birjis), Saturn (zuhal), Mercury (utarid), Mars (Bahram), and Venus (al-zuhrah). These five stars rise and run like the sun and the moon and compete with them together. All the other stars are hung from the sky like lanterns hung in mosques…’ (al-Tabari, Volume 1, pp. 235-236).My brothers and sisters, if we say that Allah and Muhammad lack understanding or knowledge, Muslims accuse us of insulting their Allah and his beloved Muhammad. Now, I ask you, dear readers, to find a name to call these Allah and Muhammad. Personally, I say they are simply ignorant.He also claims,“The sea walks in the sky? This is a great disaster.”‘God created the sea three farsakhs (about 18 kilometers) from the sky. The waves are controlled, standing in the sky by God’s command. Not a single drop is spilled. All the seas do not move, but the sea flows at the speed of an arrow. It is left to travel in the sky in harmony, as if it is a rope stretching from east to west. The sun, moon, and the five retrograde stars revolve in the depths of the waves of the sea. Thus is the word of God (as it means): “Each one swims in a circle.” “Circle” is a circular course in the depths of that sea.’ (al-Tabari, Volume 1, p. 235)Comments from the early Muslims:They said that the sun actually goes to a place of rest at night, and that the sun and moon actually “float” in a sea of water in the sky.Shalom,Dr. Maxwell Shimba, servant of Jesus Christ.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
