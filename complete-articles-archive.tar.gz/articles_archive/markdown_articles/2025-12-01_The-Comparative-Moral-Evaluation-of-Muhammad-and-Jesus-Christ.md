# The Comparative Moral Evaluation of Muhammad and Jesus Christ

**Publication Date:** December 01, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/the-comparative-moral-evaluation-of.html  
**Keyword Match:** islam  
**Word Count:** 384  
**Archived:** 2026-01-17 01:06:38  
**Date Source:** content_regex

---

The Comparative Moral Evaluation of Muhammad and Jesus ChristBy Dr. Maxwell Shimba, Shimba Theological InstituteThroughout history, both Muhammad, the prophet of Islam, and Jesus Christ, the central figure of Christianity, have been presented as exemplary models of human conduct. Islam refers to Muhammad as“al-insān al-kāmil”—the “perfect man”—and“Khatam an-Nabiyyin”—the “Seal of the Prophets.” Christianity, however, identifies Jesus Christ as the sinless Son of God, the incarnate Word, and the moral and spiritual standard for humanity (John 1:14; 1 Peter 2:22).A close theological and historical examination of their lives reveals striking contrasts. The New Testament consistently portrays Jesus as morally perfect, compassionate, and selfless, emphasizing love, humility, forgiveness, and sacrifice. His teachings uplift human dignity and encourage purity of heart and spirit (Matthew 5–7). In contrast, early Islamic sources—such asSahih al-Bukhari,Sahih Muslim, andIbn Ishaq’s Sirat Rasul Allah—record elements of Muhammad’s life that raise ethical and moral questions when compared with Christ’s example. These include accounts of multiple marriages, the marriage to Aisha at a very young age, and certain controversial practices surrounding warfare and revelation.From a Christian theological perspective, the comparison between the two figures is not merely about morality but divine nature. Jesus Christ is viewed as both fully divine and fully human, embodying the perfection of God’s moral law. Muhammad, on the other hand, is regarded in Islamic theology as a human prophet without divinity. Yet, the claim of being the “best of men” (khayr al-bashar) presents an ethical paradox when examined through a moral-theological lens.The Apostle Paul and the other apostles uniformly present Jesus as the only mediator between God and man (1 Timothy 2:5) and the ultimate revelation of God’s love (Romans 5:8). Hence, to elevate any other historical figure above Christ not only undermines biblical revelation but contradicts the Christian understanding of divine holiness and moral perfection.While Islam holds Muhammad in the highest esteem, Christian theology maintains that perfection can only be found in the divine person of Jesus Christ. The distinction between the two is not rooted in cultural bias but in the intrinsic difference between a prophet claiming human inspiration and the incarnate Word of God who embodies divine truth.ReferencesThe Holy Bible, New International Version.Sahih al-Bukhari, Vol. 7, Book 62.Sahih Muslim, Book of Marriage.Ibn Ishaq,Sirat Rasul Allah(The Life of Muhammad).John 1:1–14; 1 Peter 2:22; Romans 5:8; 1 Timothy 2:5.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
