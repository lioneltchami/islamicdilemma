# An Academic Reassessment of Muhammad as Uswa Ḥasana (Qur’an 33:21)

**Publication Date:** January 02, 2026  
**Original URL:** https://www.maxshimbaministries.org/2026/01/an-academic-reassessment-of-muhammad-as.html  
**Keyword Match:** islam  
**Word Count:** 352  
**Archived:** 2026-02-08 06:53:31  
**Date Source:** content_regex

---

An Academic Reassessment of Muhammad asUswa Ḥasana(Qur’an 33:21)By Dr. Maxwell Shimba, Shimba Theological InstituteThis brief analysis critically examines the claim that Muhammad represents theuswa ḥasana(“excellent pattern of conduct”) by evaluating his marital and sexual history through primary Islamic sources—Qur’an andṢaḥīḥHadith.Muhammad’s early marriage to Khadijah bint Khuwaylid occurred within a socially conventional framework: she was a wealthy widow who proposed marriage and supported him financially. However, following his rise to political and military authority in Medina, his marital practices expanded in ways that raise serious ethical concerns.The marriage to ʿĀʾisha is particularly controversial. Canonical Hadith state she was married at six and the marriage consummated at nine (Ṣaḥīḥ al-Bukhārī 5134; Ṣaḥīḥ Muslim 1422), an act incompatible with contemporary moral standards and difficult to reconcile with claims of timeless moral exemplarity.Muhammad’s marriage to Zaynab bint Jaḥsh—formerly the wife of his adopted son Zayd ibn Ḥāritha—was preceded by Qur’anic abrogation of adoption laws (Qur’an 33:4–5), followed by a direct command for Muhammad to marry her (33:37). A well-known report attributed to ʿĀʾisha comments, “I see that your Lord hastens to fulfill your desires” (Ṣaḥīḥ al-Bukhārī 4788), highlighting internal early-Muslim discomfort with this episode.Further, sources record Muhammad’s marriage to Ṣafiyya bint Ḥuyayy shortly after the Battle of Khaybar, where her father, husband, and tribe were killed (Ṣaḥīḥ Muslim 1365). Other women—such as Juwayriyya bint al-Ḥārith, Rayḥāna bint Zayd, and Māriya al-Qibṭiyya—entered his household as war captives or concubines, practices explicitly permitted within the Qur’anic framework of slavery (e.g., Qur’an 33:50; 66:1).Qur’an 33:50 grants Muhammad privileges unavailable to other Muslim men, including exemption from the four-wife limit and permission to take any woman who “offers herself” to him—raising questions about moral equality and prophetic restraint.In total, Islamic tradition attributes to Muhammad eleven wives alongside concubines, without recorded repentance or moral critique within the text itself. When these practices—child marriage, sexual slavery, and prophetic privilege—are presented as divinely sanctioned and eternally normative, they challenge the coherence of the claim that Muhammad’s life constitutes a universally applicable moral ideal.The question remains unavoidable:Can conduct rooted in 7th-century power, conquest, and privilege credibly function as an eternal moral standard for humanity?

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
