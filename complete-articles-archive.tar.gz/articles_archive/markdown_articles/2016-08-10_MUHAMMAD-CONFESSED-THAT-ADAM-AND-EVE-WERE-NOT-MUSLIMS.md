# MUHAMMAD CONFESSED THAT ADAM AND EVE WERE NOT MUSLIMS

**Publication Date:** August 10, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/12/muhammad-confessed-that-adam-and-eve.html  
**Keyword Match:** islam  
**Word Count:** 261  
**Archived:** 2026-01-01 06:36:42  
**Date Source:** content_regex

---

Wednesday, August 10, 2016MUHAMMAD CONFESSED THAT ADAM AND EVE WERE NOT MUSLIMSTHIS IS A GREAT DISASTER FOR MUSLIMSMy brothers and sisters, today I want to inform Muslims that Adam and Eve were not Muslims, contrary to what they claim.Let me help you a little:Do you know that Islam was founded by Muhammad and did not exist before him?Islam, which was founded by Muhammad, the Messenger of Allah (s.w.t.), around 610 A.D. in Mecca, was completed with the help of his cousin, companion, and successor, Ali ibn Abi Talib, around 632 A.D. in Medina. It covers a period of about ninety years from 570 A.D., when Muhammad was born in Mecca, until 661 A.D., when his successor Ali ibn Abi Talib was killed in the city of Kufa.If you doubt this, then answer the following:Show me the word or name“ISLAM”in the Torah that Allah revealed to Moses before the Qur’an.Show me the word or name“ISLAM”in the Psalms that Allah revealed to David before the Qur’an.Show me the word or name“ISLAM”in the Gospel that Allah revealed to Jesus before the Qur’an.Remember: I have no time for Qur’anic verses, because the Qur’an is not the collection of books called the “Bible.” Respond to me using the Torah, the Psalms, and the Gospel that Allah supposedly revealed before the Qur’an was given to Muhammad.If there is any Muslim anywhere in the world who can show meISLAM, or the nameISLAM, or the wordISLAMin those books,TODAY I WILL CONVERT AND BECOME A MUSLIM.Come to Jesus, the living and almighty God.It is I,Max Shimba, servant of Jesus Christ.www.maxshimbaministries.org

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
