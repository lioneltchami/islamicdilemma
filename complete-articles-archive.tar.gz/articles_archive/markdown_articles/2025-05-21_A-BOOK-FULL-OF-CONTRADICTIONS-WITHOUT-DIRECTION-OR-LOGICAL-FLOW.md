# A BOOK FULL OF CONTRADICTIONS, WITHOUT DIRECTION OR LOGICAL FLOW

**Publication Date:** May 21, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/05/a-book-full-of-contradictions-without.html  
**Keyword Match:** muslim  
**Word Count:** 459  
**Archived:** 2026-01-15 12:30:11  
**Date Source:** content_regex

---

When we quote a verse with contradictions, hatred, or exposing the lies of Muslims in the Qur'an, Muslims vehemently deny it, claiming that the verse is incomplete unless we read the verse preceding or following it.So let's look at these verses written in the sequence of numbers 191, 192, 193, 194, and 195 to see if they indeed build a logical argument. You will be surprised by the Qur'an, which is claimed to be a good guide for Muslims.NOTE:My explanations are in brackets (…).QUR’AN: Surah Al-Baqarah 2:191-195:191. And kill them wherever you overtake them, and expel them from wherever they have expelled you; for fitnah (persecution) is worse than killing. And do not fight them at the Sacred Mosque until they fight you there. But if they fight you, then kill them. Such is the recompense of the disbelievers.(…if persecution is worse than killing, why then should you kill them? Sometimes it says not to fight them at the Sacred Mosque, and other times to fight them there. Which one is it? Is it the Muslims who retaliate or Allah?)192. But if they cease, then indeed, Allah is Forgiving and Merciful.(…who is being forgiven here, the disbelievers or the Muslims because both have sinned by fighting)193. Fight them until there is no more fitnah, and the religion is entirely for Allah. But if they cease, then there is to be no aggression except against the oppressors.(…but did not Allah say in verse 192 that He is forgiving? How then does He command to fight them (the disbelievers)?)194. [Fighting in] the sacred month is for [aggression committed in] the sacred month, and for [all] violations is legal retribution. So whoever has assaulted you, then assault him in the same way that he has assaulted you. And fear Allah and know that Allah is with those who fear Him.(…so attacking someone who attacks you is fearing God? SERIOUSLY????)195. And spend in the way of Allah and do not throw [yourselves] with your [own] hands into destruction [by refraining]. And do good; indeed, Allah loves the doers of good.(…but did not Allah say in verses 191, 193, and 194 to fight them and kill them? How then does He command you not to destroy them with your own hands?)EVALUATION:The Qur'an is a book full of contradictions, fitnah, hatred, and permission to kill non-Muslims. Its verses lack logical flow. Each verse stands on its own and does not relate to the preceding or following verse.In one verse, Allah commands his followers to strike non-Muslims, while in another, he commands them to forgive. Which one should be followed?Allah is like a bat, chameleon, double-tongued, and centipede—the evidence is in his writings and the behavior of his followers.ShalomDr. Max Shimba for Max Shimba Ministries Org

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
