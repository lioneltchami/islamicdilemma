# Jesus is God Al Hadi according to the Quran

**Publication Date:** January 07, 2026  
**Original URL:** https://www.maxshimbaministries.org/2026/01/jesus-is-god-al-hadi-according-to-quran.html  
**Keyword Match:** quran  
**Word Count:** 0  
**Archived:** 2026-01-21 18:33:52  
**Date Source:** content_regex

---



---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
