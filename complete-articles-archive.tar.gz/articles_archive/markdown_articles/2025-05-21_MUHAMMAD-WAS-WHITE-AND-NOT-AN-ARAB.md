# MUHAMMAD WAS WHITE AND NOT AN ARAB

**Publication Date:** May 21, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/05/muhammad-was-white-and-not-arab.html  
**Keyword Match:** muslim  
**Word Count:** 410  
**Archived:** 2025-12-05 06:21:57  
**Date Source:** content_regex

---

SO MUHAMMAD WAS WHITE AND NOT AN ARABTHIS IS A GREAT TRAGEDY FOR MUSLIMSDear Reader,Muslims often like to say that Jesus was white and that the actor who portrays Jesus in movies is actually Jesus himself. Today I have decided that we learn a little about the Prophet of Allah. Was he an Arab or a white man? Without wasting time, start reading his authentic hadiths.Sahih Bukhari 1:3:63He made his camel kneel in the mosque, then tied its leg with a rope, and then asked, "Who among you is the Prophet Muhammad?" At that time the Prophet was sitting among us (his companions) leaning on his arm. We replied, "This WHITE man who is leaning on his arm is Muhammad." Then he said, "O son of 'Abdul Muttalib."Volume 4, Book 56, Number 744:Narrated Isma'il bin Abi Khalid:I heard Abii Juhaifa say: I saw the Prophet of Allah, and Al-Hasan bin 'Ali resembled him. I asked Abu-Juhaifa, tell me about him. He replied that the Prophet of Allah was a white man with black and slightly grey hair in his beard. He promised to give us 13 she-camels, but the Prophet of Allah died before fulfilling his promise.So, the Prophet of Allah was white. That's why Allah does not like Africans and calls them infidels.Volume 2, Book 17, Number 122:Narrated 'Abdullah bin Dinar:My father said, "I heard Ibn 'Umar reciting the poetry of Abu Talib: And a WHITE man (meaning the Prophet) to whom we turn to for rain, the caretaker of orphans, and the protector of widows."Volume 2, Book 17, Number 141:Narrated Anas bin Malik:The Prophet never raised his hands for any prayer except for the prayer of Istisqa' (asking for rain) and he would raise them so high that the whiteness of his armpits could be seen.Volume 1, Book 8, Number 367:The Prophet of Allah showed his thighs, and I saw the whiteness of his thighs.I hope you have read those hadiths about Muhammad and learned something about the ethnicity or nationality of the Prophet of Allah. Muhammad was white, and we do not read anywhere that he denied his whiteness.Why did the early Muslims say that Muhammad was white?Why did Muhammad not deny claims of him being white?SO MUHAMMAD WAS WHITE AND NOT AN ARABGod bless you greatly,In His Service,Max Shimba Ministries Org.MAX SHIMBA MINISTRIES ORG ©2015. ALL RIGHTS RESERVEDEveryone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
