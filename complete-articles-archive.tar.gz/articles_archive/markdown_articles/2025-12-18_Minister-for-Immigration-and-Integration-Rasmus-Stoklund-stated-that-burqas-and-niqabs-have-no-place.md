# Minister for Immigration and Integration Rasmus Stoklund stated that burqas and niqabs "have no place in a Danish classroom

**Publication Date:** December 18, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/minister-for-immigration-and.html  
**Keyword Match:** burqa  
**Word Count:** 19  
**Archived:** 2026-02-08 04:35:21  
**Date Source:** content_regex

---

Minister for Immigration and Integration Rasmus Stoklund stated that burqas and niqabs "have no place in a Danish classroom."#denmark

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
