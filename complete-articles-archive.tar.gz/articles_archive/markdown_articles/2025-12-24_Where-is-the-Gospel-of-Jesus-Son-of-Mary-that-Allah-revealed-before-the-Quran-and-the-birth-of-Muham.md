# Where is the Gospel of Jesus Son of Mary that Allah revealed before the Quran and the birth of Muhammad?

**Publication Date:** December 24, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/where-is-gospel-of-jesus-son-of-mary.html  
**Keyword Match:** quran  
**Word Count:** 0  
**Archived:** 2026-03-30 01:48:38  
**Date Source:** content_regex

---



---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
