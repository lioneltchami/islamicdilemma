# Daughter of Lancashire Imam Converts to Christianity and Is Baptized

**Publication Date:** December 20, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/daughter-of-lancashire-imam-converts-to.html  
**Keyword Match:** islam  
**Word Count:** 102  
**Archived:** 2026-01-13 06:23:31  
**Date Source:** content_regex

---

Daughter of Lancashire Imam Converts to Christianity and Is BaptizedFather Reportedly Seeking to Kill HerA 35-year-old woman, the daughter of a prominent mosque Imam in Lancashire, England, has embraced Christianity and undergone baptism. One of the major reasons for her departure from Islam was being forced into marriage at the age of 16.Now a holder of a postgraduate degree from a leading British university, she has been on the run for years. She has relocated more than 45 times, living in hiding to escape family members who have allegedly issued a death sentence against her because of her conversion.Full story available at:http://www.dailymail.co.uk/news/article-500087/Imams-daughter-hiding-conversion-Christianity-sparked-death-threats.html

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
