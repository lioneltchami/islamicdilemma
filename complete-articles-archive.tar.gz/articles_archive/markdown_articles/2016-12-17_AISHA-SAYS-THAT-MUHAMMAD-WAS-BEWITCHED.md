# AISHA SAYS THAT MUHAMMAD WAS BEWITCHED

**Publication Date:** December 17, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/12/aisha-says-that-muhammad-was-bewitched.html  
**Keyword Match:** muhammad  
**Word Count:** 464  
**Archived:** 2025-12-11 12:29:40  
**Date Source:** content_regex

---

Saturday, December 17, 2016AISHA SAYS THAT MUHAMMAD WAS BEWITCHEDMuhammad Was Once Bewitched (By a Spell, “Under a Spell”)“‘Aisha narrates: The Prophet was affected by magic to the point that he would imagine he had done something when he had not done it. One day he prayed (to Allah) for a very long time, then said, ‘I feel that Allah has given me guidance on how to cure myself.’ …”Bukhari, Volume 4, Book 54 (The Beginning of Creation), Chapter 10, Hadith no. 490, p. 317.See also:Volume 4, Book 53 (Obligations of Khumus), Chapter 34, no. 400, p. 267Volume 8, Book 73 (Good Manners), Chapter 56, no. 89, pp. 56–57Volume 8, Book 75 (Book of Invocations), Chapter 59, no. 400, pp. 266–267Volume 7, Hadith nos. 658–660, pp. 441–443Also seeSahih Muslim, Volume 2, Book 4 (Book of Prayer), Chapter 309, no. 1888, p. 411.Muhammad was bewitched. ‘Aisha narrated: The Prophet continued for some time believing that he was having sexual relations with his wives when he was not. One day he said to me:“O ‘Aisha! God has instructed me concerning the matter I asked Him about. Two men came; one sat at my feet and the other near my head. The one near my feet said to the one near my head (pointing at me), ‘What is wrong with this man?’ The other replied, ‘He has been affected by magic.’ The first asked, ‘Who cast the spell on him?’ The other replied, ‘Lubaid bin A’sam.’ The first asked, ‘With what (material)?’ The other replied, ‘With the pollen of a male date palm and a comb, in which hair was placed, and buried under a stone in the well of Dharwan.’”Then the Prophet went to that well and said:“This is the same well that was shown to me in the dream. The tops of its date palms look like the heads of devils, and its water looks like a mixture of henna.”‘Aisha added: “The magician Lubaid bin A’sam was from the tribe of Bani Zuraiq, an ally of the Jews.”Bukhari, Volume 8, Book 73 (Good Manners), Chapter 56, no. 89, p. 57.See alsoBukhari, Volume 8, Book 75 (Book of Invocations), Chapter 59, no. 400, p. 266.1. Why should we follow a Prophet who was bewitched?2. Is there any Prophet in the Bible who was ever bewitched?3. Why did Allah fail to protect His Prophet from the power of sorcery?4. Where do we read that Muhammad was prayed for and delivered from the spell?There is no evidence anywhere stating that Muhammad was prayed for and that the spell left him. This is a tragedy for the Prophet of Allah to die while still under the effects of sorcery.Dear reader,Anyone who dies while bewitched and filled with demons will end up in the Hellfire.Come to the living Jesus.Max Shimba Ministries

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
