# Allah Has One Eye — So Allah Is an Infidel

**Publication Date:** January 01, 2026  
**Original URL:** https://www.maxshimbaministries.org/2026/01/allah-has-one-eye-so-allah-is-infidel.html  
**Keyword Match:** muslim  
**Word Count:** 198  
**Archived:** 2026-01-05 01:13:16  
**Date Source:** content_regex

---

Allah Has One Eye — So Allah Is an InfidelThe hadith of Anas (may Allah be pleased with him) says that the Prophet (peace be upon him) said:“There is no prophet who was sent except that he warned his people about the one-eyed god. Understand! He has one eye, and indeed your Lord does not have one eye. Between his eyes is written the wordKafir(Infidel).”(Bukhari, Hadith No. 245, Volume 9)Today I have now understood why Muslims always oppose the belief that Jesus is God. It is because Jesus came having both eyes, whereas their god Allah has only one eye, and in the place of the other eye is written the wordKafir.Muslims will never accept Jesus as God until the day they see someone come with only one eye—then they will accept him.O Muslim, stop struggling and relying on a being who has only one eye. Come to Jesus, the great God, who has both eyes and who is able to see everywhere—even into the hearts and minds of people. Abandon that one-eyed one, because he cannot see far, and that is why he could not even raise the dead or perform miracles.ShalomMax Shimba Ministries Orgwww.maxshimbaministries.orgJune 22, 2014

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
