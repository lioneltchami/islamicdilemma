# Disturbing acts of revenge are taking place in Australia. Pig heads had been thrown at Muslim graves #BondiBeach #Australia #SydneyNews

**Publication Date:** December 18, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/disturbing-acts-of-revenge-are-taking.html  
**Keyword Match:** muslim  
**Word Count:** 17  
**Archived:** 2026-01-03 12:25:45  
**Date Source:** content_regex

---

Disturbing acts of revenge are taking place in Australia. Pig heads had been thrown at Muslim graves#BondiBeach#Australia#SydneyNews

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
