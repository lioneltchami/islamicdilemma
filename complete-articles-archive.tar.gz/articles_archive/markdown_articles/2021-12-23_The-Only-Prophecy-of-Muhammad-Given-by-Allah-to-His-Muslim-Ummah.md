# The Only Prophecy of Muhammad Given by Allah to His Muslim Ummah

**Publication Date:** December 23, 2021  
**Original URL:** https://www.maxshimbaministries.org/2025/07/the-only-prophecy-of-muhammad-given-by.html  
**Keyword Match:** islam  
**Word Count:** 307  
**Archived:** 2025-12-26 12:27:34  
**Date Source:** content_regex

---

Thursday, December 23, 2021It is recorded within Islamic tradition that the Prophet Muhammad taught his followers that one of the signs of the Day of Judgment (Qiyamah) would involve the shaking of women’s buttocks from a particular tribe. This peculiar sign is explicitly recorded in one of the authentic Hadith collections.Hadith of Abu Huraira (may Allah be pleased with him):The Prophet Muhammad (peace and blessings be upon him) said:"The Hour will not be established until the buttocks of the women of the tribe of Daus move while going around Dhi-al-Khalasa."Explanation:Dhi-al-Khalasawas an idol that the Daus tribe used to worship during the pre-Islamic period of ignorance (Jahiliyya). This idol was a central object of idolatrous rituals, and it is noted in the Hadith that one of the signs preceding the establishment of the Last Day (Qiyamah) would be the women of this tribe moving their buttocks around this very idol.Source:Sahih al-Bukhari, Volume 9, Book 88, Hadith Number 232.Arabic Text of the Hadith:حديث أبي هريرة رضي الله عنه أن النبي صلى الله عليه وسلم قال:"لن تقوم الساعة حتى تضطرب أليات نساء دوس حول ذي الخلصة"Translation of the Arabic Text:Narrated Abu Huraira (may Allah be pleased with him): The Prophet (peace and blessings be upon him) said:"The Hour will not be established until the buttocks of the women of the tribe of Daus move while going around Dhi-al-Khalasa."Reference:Sahih Bukhari — Volume 9, Book 88, Hadith 232Concluding Note:This narration reflects one of the unusual eschatological signs described in early Islamic literature concerning the Day of Judgment. The mention of such an occurrence reveals the cultural and religious context of 7th-century Arabia, where certain pre-Islamic idols and tribal practices remained significant symbols even in prophetic warnings. From a comparative theological perspective, it underscores the unique character of some Islamic eschatological traditions when juxtaposed with those of other Abrahamic faiths.Shalom,Max Shimba Ministries Org

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
