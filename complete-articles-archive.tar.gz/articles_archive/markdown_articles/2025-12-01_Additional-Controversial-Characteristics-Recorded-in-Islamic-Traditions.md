# Additional Controversial Characteristics Recorded in Islamic Traditions

**Publication Date:** December 01, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/additional-controversial.html  
**Keyword Match:** islam  
**Word Count:** 343  
**Archived:** 2025-12-02 12:29:06  
**Date Source:** content_regex

---

Additional Controversial Characteristics Recorded in Islamic Traditions1. He claimed revelations only when convenientIn several hadith, revelations appeared exactly when they solved his personal or political problems (e.g., Qur’an 33:37 regarding Zaynab).2. He married his adopted son’s wifeThe marriage toZaynab bint Jahsh, formerly the wife of his adopted son Zayd, caused scandal even among his companions (Qur’an 33:37–40).3. He allowed temporary marriages (Mut’ah)Mut’ah (temporary sexual contracts) were practiced during Muhammad’s time, later banned by Umar, showing internal contradictions in Islamic law.4. He approved the killing of criticsBiographical sources record the assassinations of poets and critics such asKa’b bin al-AshrafandAsma bint Marwan.5. He ordered violent raids on caravansEarly Islamic expansion involved economic raids (ghazawat), including the raid on the Quraysh caravan that triggered the Battle of Badr.6. He married multiple women for political reasonsHis marriages often strengthened tribal alliances; this is acknowledged in classical Islamic scholarship.7. He cursed entire groups of peopleHadith collections record him cursing groups such as women, Jews, poets, and tribes that opposed him.8. He claimed special privileges to break moral lawsIslamic law gives Muhammad exceptions: more wives, exemption from certain restrictions, special allowances on marriage, etc.9. He believed magic was cast on himSahih al‑Bukhari states that Muhammad believed he was magically bewitched and unable to distinguish reality.10. He engaged in harsh punishmentsReports describe beheading, amputation, and severe retribution against opponents (e.g., the Banu Qurayza incident).11. He spoke words not found in the Qur’anHadith record that verses were eaten by a sheep, others forgotten, others abrogated — raising questions of textual stability.12. He allowed beating of womenSahih Hadith record permission to strike a disobedient wife, though not severely.13. He claimed the Qur’an was protected but also missing versesIslamic tradition acknowledges missing or forgotten verses after his death, such as the verse of stoning.14. He declared himself the final prophet based on personal testimonyNo external witness or prophecy (from Torah or Gospel) confirms this claim; the testimony comes from Muhammad alone.15. He allowed child concubinage with slave girlsConcubines likeMaria the Coptwere taken as part of war spoils, including sexual relations without formal marriage.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
