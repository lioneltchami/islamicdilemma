# Where in the Qur’an does it explicitly state that Muhammad is a son or direct descendant of Abraham, or where Abraham himself declares Muhammad as his descendant?

**Publication Date:** December 16, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/where-in-quran-does-it-explicitly-state.html  
**Keyword Match:** muhammad  
**Word Count:** 296  
**Archived:** 2025-12-17 06:22:10  
**Date Source:** content_regex

---

Professional, Text-Based AnalysisQuestion:Where in the Qur’an does it explicitly state that Muhammad is a son or direct descendant of Abraham, or where Abraham himself declares Muhammad as his descendant?Answer:There isno verse in the Qur’anin which Abraham explicitly names Muhammad as his son or descendant, nor any verse where Muhammad is directly identified as Abraham’s biological offspring.What the Qur’an does affirm isAbraham’s lineage through Ishmael, and it places Muhammad within thebroader Abrahamic tradition, not through an explicit genealogical statement.Key Qur’anic Passages Commonly CitedAbraham and Ishmael“And We gave him Isaac and Jacob, and guided them; and Noah We guided before; and among his descendants, David, Solomon… and Ishmael…”(Qur’an 6:84–86)Ishmael is clearly identified as Abraham’s son.Muhammad is not mentioned here or elsewhere as Abraham’s son.Prayer of Abraham and Ishmael“Our Lord, raise among them a messenger from among themselves who will recite to them Your verses…”(Qur’an 2:129)This verse isinterpreted by later Islamic traditionas a reference to Muhammad, but:Muhammad isnot namedNo biological lineage is statedThe connection isinterpretive, not explicitReligion of Abraham“Then We revealed to you [Muhammad]: Follow the religion of Abraham, inclining toward truth.”(Qur’an 16:123)This establishestheological continuity, notbiological descent.Muhammad Identified by His Immediate Lineage“Muhammad is not the father of any of your men, but the Messenger of Allah…”(Qur’an 33:40)Notably, the Qur’annever traces Muhammad’s genealogy back to Abraham, despite doing so for other prophets.Scholarly ConclusionThe Qur’andoes not explicitly statethat Muhammad is a son or direct descendant of Abraham.Abrahamnever declares Muhammad as his descendantin the Qur’anic text.The claim that Muhammad descends from Abrahamcomes from later Islamic historiography and tradition, not from a clear Qur’anic assertion.The Qur’an connects Muhammad to Abrahamtheologically, not genealogically.In summary:Any assertion that the Qur’an plainly teaches that Muhammad is a direct descendant of Abrahamgoes beyond the explicit wording of the Qur’anand relies on post-Qur’anic tradition rather than direct textual evidence.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
