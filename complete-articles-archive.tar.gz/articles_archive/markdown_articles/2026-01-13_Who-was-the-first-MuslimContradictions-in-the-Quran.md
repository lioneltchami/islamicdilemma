# Who was the first Muslim?Contradictions in the Qur’an

**Publication Date:** January 13, 2026  
**Original URL:** https://www.maxshimbaministries.org/2026/01/who-was-first-muslimcontradictions-in.html  
**Keyword Match:** muslim  
**Word Count:** 0  
**Archived:** 2026-02-01 01:42:07  
**Date Source:** content_regex

---



---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
