# CONTRADICTIONS IN THE QURAN: HOW WAS ADAM CREATED?

**Publication Date:** May 21, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/05/contradictions-in-quran-how-was-adam.html  
**Keyword Match:** quran  
**Word Count:** 247  
**Archived:** 2026-01-15 01:06:05  
**Date Source:** content_regex

---

From what was man created? A drop of blood? Water? Clay? Dust?This is indeed a significant problem in the nation of Allah. Was Allah an artist, or who was he? He seems to enjoy mixing things up.Today, ALLAH HAS CREATED CONFUSION regarding the creation of man. Let’s begin by reading his book, which was revealed by his assistant, Jibril.Was Adam created from a drop of blood?Quran 96:1-2Read in the name of your Lord who created,Created man from a clinging substance. ***Allah says that man was created from a drop of blood. Let's continue to gain knowledge from the Quran.Was Adam created from water?Quran 25:54And it is He who has created man from water and made for him a lineage and marriage relationship. And your Lord is all-powerful. ***Allah mixes things up. Now he says man was created from water. Let’s continue to read Allah's artistry.Was man created from clay?Quran 15:26And We created man from sounding clay, from mud molded into shape. ***Allah has changed again; now he says man was created from clay. Isn't this a problem?Continue to gain knowledge.Was man created from dust?Quran 30:20And among His signs is this, that He created you from dust; and then, behold, you are human beings scattered widely. ***Dear friends, was the Quran really revealed from God? Why is there confusion everywhere?From what was man created?A drop of blood? Water? Clay? Dust?Indeed, Allah knows everything, although he doesn't know how he created Adam!ShalomDr. Max Shimba for Max Shimba Ministries Org

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
