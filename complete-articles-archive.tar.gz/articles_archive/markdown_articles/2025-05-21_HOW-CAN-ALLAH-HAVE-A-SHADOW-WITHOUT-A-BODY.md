# HOW CAN ALLAH HAVE A SHADOW WITHOUT A BODY?

**Publication Date:** May 21, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/05/how-can-allah-have-shadow-without-body.html  
**Keyword Match:** muslim  
**Word Count:** 131  
**Archived:** 2025-11-30 03:29:21  
**Date Source:** content_regex

---

ALLAH'S SHADOWHOW CAN ALLAH HAVE A SHADOW WITHOUT A BODY?When I say Allah is a being, Muhammadans get upset. Now I have provided your own book.Narrated by Abu Huraira: The Prophet Muhammad said, "Seven people will be shaded by Allah under His shadow on the day when there will be no shadow but His." (Abu Hurairah & collected in Saheeh al-Bukhari (English trans.) vol.1, p.356, no.629 & Saheeh Muslim (English trans.) vol.2, p.493, no.2248))https://www.sunnah.com/bukhari/24/27More evidence:Jami' at-Tirmidhi, Book 14, Hadith 109:https://www.sunnah.com/tirmidhi/14/109Bulugh al-Maram, Book 4, Hadith 632:https://www.sunnah.com/urn/2107660More Reference:Sahih al-Bukhari 1423In-book reference: Book 24, Hadith 27USC-MSA web (English) reference: Vol. 2, Book 24, Hadith 504Don't panic, answer with the verse. How can your Allah have a shadow without a body?Shalom.Max Shimba, a servant of Jesus Christ, the Almighty God and our Savior. Titus 2:13

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
