# ALLAH ADMITS THAT HE HAS A FACE LIKE CREATED BEINGS

**Publication Date:** August 3, 2015  
**Original URL:** https://www.maxshimbaministries.org/2025/12/allah-admits-that-he-has-face-like.html  
**Keyword Match:** allah  
**Word Count:** 376  
**Archived:** 2025-12-16 06:22:59  
**Date Source:** content_regex

---

Monday, August 3, 2015ALLAH ADMITS THAT HE HAS A FACE LIKE CREATED BEINGSMy brothers,I begin by saying that this is a very great tragedy for our brothers, the descendants of Adam, who deny that Allah has no likeness.Today I will give you several examples as evidence that Allah is a created being.Now, join me directly as we learn about this Allah who is a created being.Allah says:“Wherever you turn, there is the FACE of Allah.”Surah 2, Ayah 115.In that verse above, Allah has already answered those who argue that Allah has no FACE. Is having a FACE not a characteristic of human beings?Allah says:“كُلُّ شَيْءٍ هَالِكٌ إِلَّا وَجْهَهُ”(Everything will perish except His FACE (Allah).) Surah 28, Ayah 88.My brothers, Allah continues admitting that He has a FACE like created beings.Continue reading:ALLAH ADMITS THAT HIS FACE HAS EYES“At one time the EYES of Allah were hurting, and the Angels went to see Him, and it is said that Allah shed Tears because of the Flood of Prophet Noah until His eyes became red.”(Al-Milal wannihal, Vol. 1 p. 141)I know Muslims will deny that this hadith isda’if(weak) and that it is not in the Qur’an. Let us continue reading another evidence that Allah has two eyes and that the wordKafiris written between His eyes.The hadith of Anas (r.a): He said, the Prophet (s.a.w) said:“There has been no Prophet sent except that he warned his people about the one-eyed liar. Know that he has one eye, and indeed your Lord is not one-eyed—between His eyes is written the word ‘KAFIR.’”(Bukhari, Hadith No. 245, Volume 9)ALLAH ADMITS THAT HE HAS EARS AND EYESSurah An-Nisa 58:“Indeed Allah commands you to return trusts to whom they belong, and when you judge between people, judge with justice. Indeed, the things Allah advises you are very good. Indeed, Allah is the One who HEARS and the One who SEES.”Muslims, I know this is a thorn in your hearts.Dear readers, you have already understood that Allah is a created being like humans, and He has a FACE with EYES and EARS.May God bless you greatly.In His Service,Max Shimba Ministries Org.MAX SHIMBA MINISTRIES ORG ©2015. ALL RIGHTS RESERVEDEveryone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
