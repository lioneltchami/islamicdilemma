# Controversy: The Noah of the Quran is Different from the Noah of the Bible

**Publication Date:** October 16, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/05/controversy-noah-of-quran-is-different.html  
**Keyword Match:** muslim  
**Word Count:** 450  
**Archived:** 2026-01-19 18:21:47  
**Date Source:** content_regex

---

Sunday, October 16, 2016Controversy: The Noah of the Quran is Different from the Noah of the BibleDear Reader,Muslims often assert that the Quran is a comprehensive book that explains everything and is self-sufficient, claiming it is a revelation from Almighty God, while criticizing the Bible as not being from God. I will present two verses from the Bible and then two verses from the Quran, followed by a question.WHEN DID THE FLOOD OCCUR ACCORDING TO THE BIBLE?Genesis 7:6"Noah was six hundred years old when the floodwaters were on the earth."The Bible, which is claimed not to be from God, states that Noah was six hundred (600) years old when the flood occurred. It also explains the years of Noah after the flood.Genesis 9:28"And Noah lived after the flood three hundred and fifty years."HOW OLD WAS NOAH WHEN HE DIED?Genesis 9:29"So all the days of Noah were nine hundred and fifty years; and he died."We are told by the Bible that Noah lived three hundred and fifty (350) years after the flood, and he died at the age of nine hundred and fifty (950) years. This is the total number of years Noah lived. Now let's turn to the Quran and then ask a question.WHEN DID THE FLOOD OCCUR ACCORDING TO THE QURAN?Quran 29:14-1514. "And indeed We sent Noah to his people, and he stayed among them a thousand years less fifty years; so the flood overtook them while they were wrongdoers."15. "But We saved him and the companions of the ship, and We made it a sign for the worlds."THE COMPLETE DISCUSSION:The Bible says that the flood occurred when Noah was 600 years old. The Quran says that the flood occurred when Noah was 950 years old, which corresponds to the age at which Noah died according to the Bible. The Bible says that Noah lived 350 years after the flood and died at the age of 950 years, which matches the age at which the flood occurred according to the Quran.QUESTIONS:According to the Quran, Noah was 950 years old when the flood came, while the Bible says he was 600 years old when the flood came and died at the age of 950. How many years did Noah live after the flood according to the 950 years mentioned at the time of the flood in the Quran?Or did he die in the same year of the flood, being 950 years old as stated in the Quran at the time of the flood?Note:Answers should be based solely on the Quran, the book claimed to be from God. If it is not self-sufficient, please state so, and I will allow you to use even newspapers and magazines.For Max Shimba Ministries Org.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
