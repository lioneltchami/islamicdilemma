# ALLAH ADMITS THAT CHRISTIANITY IS A RELIGION THAT PRECEDED ISLAM

**Publication Date:** May 21, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/05/allah-admits-that-christianity-is.html  
**Keyword Match:** islam  
**Word Count:** 333  
**Archived:** 2026-01-26 12:31:54  
**Date Source:** content_regex

---

SO MUHAMMAD IS A LIAR WHEN HE SAID ISLAM EXISTED SINCE ADAMNow let’s read Tafsir al-Bahr al-Muhit below: Surah An-Nahl 125Explanation: Surah An-Nahl * 125. O Prophet! Invite people to the Way of Truth that your Lord has called your people to follow. And in your invitation, use the approach that suits each of them. Call those with high ranks among them with words of wisdom according to their understanding. And for the rest of the common people among them, call them by giving them relevant admonitions and using examples of the matters they deal with, guiding them to the Truth, and lead them on the straightforward path that suits them. And argue with the people of the previous religions, i.e., Jews and Christians, using intellectual arguments, logic, and gentle words, and good discussions, not harsh words and insults, to persuade and attract them. This is the way of Da'wah (invitation), calling people to approach Allah—people of all faiths. So follow this path when you call, and after that, leave the rest to your Lord, who knows who among them is deeply immersed in misguidance and far from the path of salvation, and who among them is safe, has been guided, and believes in what you have brought to them.ALLAH SAYS THAT CHRISTIANITY IS A PRECEDING RELIGION. SO ISLAM DID NOT EXIST BEFORE CHRISTIANITY.http://www.iium.edu.my/deed/quran/swahili/without/c16.htmIS IT TRUE THAT CHRISTIANITY AND THE CHURCH EXISTED BEFORE ISLAM?Let's read about Moses. Did he enter a CHURCH?Acts 7:37 This is the Moses who told the Israelites, ‘God will raise up for you a prophet like me from your own people.’38 He was in the assembly in the wilderness with the angel who spoke to him on Mount Sinai, and with our ancestors; and he received living words to pass on to us.Moses answers Muslims by stating that he was in the Church when he was in the wilderness. Thus, Moses was not a Muslim, nor did he ever enter a Mosque.Shalom,Dr. Max Shimba for Max Shimba Ministries Org.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
