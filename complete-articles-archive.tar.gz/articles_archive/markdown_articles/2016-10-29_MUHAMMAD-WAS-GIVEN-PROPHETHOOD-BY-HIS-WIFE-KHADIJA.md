# MUHAMMAD WAS GIVEN PROPHETHOOD BY HIS WIFE KHADIJA

**Publication Date:** October 29, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/12/muhammad-was-given-prophethood-by-his.html  
**Keyword Match:** muhammad  
**Word Count:** 353  
**Archived:** 2026-01-28 06:26:35  
**Date Source:** content_regex

---

Saturday, October 29, 2016MUHAMMAD WAS GIVEN PROPHETHOOD BY HIS WIFE KHADIJAWhen he was in the cave, he was played with by Satan:In the book titled“The Great Wives of the Prophet and His Children”written by Sheikh Abdullah Saleh Al-Farsy, page 12, we read these words:“Then the Prophet became afraid and returned to his wife and told her what had happened; and right there a great fever came upon him and he asked to be covered with clothes. Immediately he began trembling violently, hallucinating and saying, ‘I fear for myself that Satan has played with me, destroyed my mind, and deceived me.’Lady Khadija immediately interrupted him and said: ‘Stop that; that is not what will happen. You cannot be played with by devils. Satan cannot play with a person who has your qualities. You take good care of your relatives, you carry the burdens of even people who are not yours, you show people your good traits which none possesses. You do this and you do that. Rejoice my dear; calm your heart. By Allah! I see that you have already become a prophet.’”In this incident that happened to Muhammad while he was in the cave, Muslims all over the world claim that this is the moment Muhammad (peace be upon him) receivedwahyi(revelation) and was given prophethood and apostleship.But when you reflect on this message, you will notice that even he himself did not know what had happened to him in the cave. That is why we read that when he arrived home, his wife Lady Khadija covered him with a cloth thinking he had a fever. Muhammad explained to his wife that what had happened to him was caused by “Satan”; he did not mention any angel as Muslims try to make us believe today.Because if it had been an angel—as we read in the Bible—the angel would not have hesitated to identify himself to Muhammad. This is the first point.In the end, Lady Khadija is the one whoappointedher husband Muhammad into prophethood.Today you have learned that Muhammad was given prophethood by his wife.It is I, Max Shimba, servant of Jesus Christwww.maxshimbaministries.orgOctober 29, 2016

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
