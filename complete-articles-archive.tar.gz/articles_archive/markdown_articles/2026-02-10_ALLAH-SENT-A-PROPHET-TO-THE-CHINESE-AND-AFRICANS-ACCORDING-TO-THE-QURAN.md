# ALLAH SENT A PROPHET TO THE CHINESE AND AFRICANS ACCORDING TO THE QUR’AN

**Publication Date:** February 10, 2026  
**Original URL:** https://www.maxshimbaministries.org/2026/02/allah-sent-prophet-to-chinese-and.html  
**Keyword Match:** allah  
**Word Count:** 0  
**Archived:** 2026-04-12 07:18:02  
**Date Source:** content_regex

---



---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
