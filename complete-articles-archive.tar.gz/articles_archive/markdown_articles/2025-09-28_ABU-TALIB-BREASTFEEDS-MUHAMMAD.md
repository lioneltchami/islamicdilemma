# ABU TALIB BREASTFEEDS MUHAMMAD

**Publication Date:** September 28, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/09/abu-talib-breastfeeds-muhammad.html  
**Keyword Match:** muslim  
**Word Count:** 206  
**Archived:** 2026-01-01 01:13:33  
**Date Source:** content_regex

---

ABU TALIB BREASTFEEDS MUHAMMADThe following tradition is taken from one of the most authoritative collection of hadiths for Shia Muslims:Ḥadīth #27: 120727ـ مُحَمَّدُ بْنُ يَحْيَى عَنْ سَعْدِ بْنِ عَبْدِ الله عَنْ إِبْرَاهِيمَ بْنِ مُحَمَّدٍ الثَّقَفِيِّ عَنْ عَلِيِّ بْنِ الْمُعَلَّى عَنْ أَخِيهِ مُحَمَّدٍ عَنْ دُرُسْتَ بْنِ أَبِي مَنْصُورٍ عَنْ عَلِيِّ بْنِ أَبِي حَمْزَةَ عَنْ أَبِي بَصِيرٍ عَنْ أَبِي عَبْدِ الله  قَالَ لَمَّا وُلِدَ النَّبِيُّ ﷺ مَكَثَ أَيَّاماً لَيْسَ لَهُ لَبَنٌ فَأَلْقَاهُ أَبُو طَالِبٍ عَلَى ثَدْيِ نَفْسِهِ فَأَنْزَلَ الله فِيهِ لَبَناً فَرَضَعَ مِنْهُ أَيَّاماً حَتَّى وَقَعَ أَبُو طَالِبٍ عَلَى حَلِيمَةَ السَّعْدِيَّةِ فَدَفَعَهُ إِلَيْهَا.27. Muhammad ibn Yahya has narrated from Sa‘d ibn ‘Abdillah from Ibrahim ibn Muhammad al-Thaqafi from Ali ibn al-Mu‘alla from his brother Muhammad from Durusta ibn Abu Mansur from Ali ibn Abu Hamza from Abu Basir from Abu ‘Abdallah who said: “When the Holy Prophet was born, he remained for days without milk. Abu Talib himself breastfed him and Allah sent milk through his nipples. He continued to be breasted by him for several days until Abu Talib found Halima al-Sa‘diyyah, so he gave him to her.”Sahih al-Kafi Shaykh Baqir al-BehbudiMirʾāt al-ʿUqūl fī Sharḥ Akhbār Āl al-Rasūl (5/252) Allamah Baqir al-Majlisi (Al-Kāfi – Volume 1,Book 4, Chapter #111,The Birth of The Holy Prophet and His Demise)

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
