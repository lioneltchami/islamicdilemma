# THE COMPANIONS OF MUHAMMAD WERE THIEVES

**Publication Date:** July 26, 2019  
**Original URL:** https://www.maxshimbaministries.org/2025/12/the-companions-of-muhammad-were-thieves.html  
**Keyword Match:** muhammad  
**Word Count:** 302  
**Archived:** 2026-02-07 06:45:41  
**Date Source:** content_regex

---

Friday, July 26, 2019THE COMPANIONS OF MUHAMMAD WERE THIEVESThe companions stole camels and sheep.Muhammad led that stealing and robbery.The companions cooked the meat and Muhammad distributed it.Sahih al-Bukhari Book 44 Hadith 668ENGLISH / ARABICNarrated ‘Abaya bin Rafa’a bin Raft’ bin Khadij:My grandfather said,“We were in the company of the Prophet at Dhul-Hulaifa. The people felt hungry and captured some camels and sheep (as booty). The Prophet was behind the people. They hurried and slaughtered the animals and put their meat in pots and started cooking it. (When the Prophet came) he ordered the pots to be upset and then he distributed the animals (of the booty), regarding ten sheep as equal to one camel. One of the camels fled and the people ran after it till they were exhausted. At that time there were few horses. A man threw an arrow at the camel, and Allah stopped the camel with it. The Prophet said, ‘Some of these animals are like wild animals, so if you lose control over one of these animals, treat it in this way (i.e. shoot it with an arrow).’My grandfather said,‘We may meet the enemies in the future and have no knives; can we slaughter the animals with reeds?’The Prophet said,‘Use whatever causes blood to flow, and eat the animals if the name of Allah has been mentioned on slaughtering them. Do not slaughter with teeth or fingernails and I will tell you why: It is because teeth are bones (i.e. cannot cut properly) and fingernails are the tools used by the Ethiopians (whom we should not imitate for they are infidels).’”ARABIC(Arabic text preserved as in original)Classification:SahihReferences:al-Bukhari Book of Partnership #668al-Bukhari 2488Sahih al-Bukhari Vol. 3, Book 44, Hadith 668Sahih al-Bukhari Vol. 3, Book of Partnership, Hadith 668Link:https://muflihun.com/bukhari/44/668ShalomMax Shimba, servant of Jesus Christ our God and Savior. Titus 2:13

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
