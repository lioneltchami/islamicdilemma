# Muhammad’s Jewish Sex-Slave

**Publication Date:** September 15, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/09/muhammads-jewish-sex-slave.html  
**Keyword Match:** islam  
**Word Count:** 312  
**Archived:** 2026-01-16 18:22:14  
**Date Source:** content_regex

---

According to the Sunni traditions, Muhammad had at least two sex slaves that he did not marry, namely, a Christian Coptic girl named Mariyah and a Jewish concubine named Rayhanah. I have written at length about Mariyah, so here I will focus on Rayhanah.Here is what a modern biography on Muhammad, which is based on the earliest surviving Islamic sources, writes in respect to this Jewish girl whom Muhammad had taken captive and enslaved:As to the other women and children, they were divided, together with the property, amongst the men who had taken part in the siege. Many of these captives were ransomed by the Bani Nadir at Khaybar. As part of his share the Prophet had chosen Rayhanah, the daughter of Zayd, a Nadirite, who married her to a man of Qurayzah.She was a woman of great beauty and she remained the Prophet’s slave until she died some five years later. At first he put her in the care of his aunt Salma, in whose house Rifa‘ah had already taken refuge. Rayhanah herself was averse to entering Islam, but Rifa‘ah, and his kinsmen of the Bani Hadl spoke to her about the new religion and it was not long before one of the three young converts, Tha‘labah by name, came to the Prophet and told him that Rayhanah had entered Islam, whereupon he greatly rejoiced. When it became clear that she was not pregnant,he went to her and offered to set her free and to make her his wife. But she said: “O Messenger if God, leave me in thy power; that will be easier for me and for thee.” (Martin Lings,Muhammad: His Life Based on the Earliest Sources[Inner Traditions International, Ltd., One Park Street, Rochester, Vermont 05767; 1983], p. 233; emphasis mine)Even the Muslim writings are not able to hide the fact of Muhammad being a vile, immoral, sexual deviant.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
