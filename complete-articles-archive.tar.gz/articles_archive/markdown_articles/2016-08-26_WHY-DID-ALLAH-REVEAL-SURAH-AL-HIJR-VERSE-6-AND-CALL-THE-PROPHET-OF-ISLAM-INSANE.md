# WHY DID ALLAH REVEAL SURAH AL-HIJR VERSE 6 AND CALL THE PROPHET OF ISLAM INSANE?

**Publication Date:** August 26, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/12/why-did-allah-reveal-surah-al-hijr.html  
**Keyword Match:** islam  
**Word Count:** 413  
**Archived:** 2025-12-08 06:23:40  
**Date Source:** content_regex

---

Friday, August 26, 2016WHY DID ALLAH REVEAL SURAH AL-HIJR VERSE 6 AND CALL THE PROPHET OF ISLAM INSANE?Dear brothers and sisters,The Bible says,“You will know them by their fruits.”These are the words from the Gospel ofMatthew 7:16–17—“You will know them by their fruits. Do men gather grapes from thornbushes or figs from thistles? Likewise, every good tree bears good fruit, but a bad tree bears bad fruit.”Prophet Muhammad failed to demonstrate righteousness in his mission. The work he claimed to be sent by God to do was filled with many contradictions that led people to call him“insane.”His act of marrying a six-year-old child caused great confusion, because such an act is inhumane and was never practiced by any prophet who came before him.Below is a verse from the Qur’an, said to have been revealed by the god of Islam through the angel Gabriel:Qur’an 15:6–“And they say, ‘O you upon whom the message has been sent down, indeed you are mad!’(http://www.quranitukufu.net/015.html)Muhammad was calledinsanein the presence of the public. What is striking is that he never denied this accusation. Instead, he remained silent — a silence that itself served as an admission of guilt. His own writings and Islamic sources further confirm this insanity.Let us look briefly at his own account inKitab al-Tabaqat al-Kabir (The Book of Major Classes)byIbn Sa’d, translated byS. Moinal Haq, Vol. 4, p. 225, where Muhammad is recorded as saying:“O Khadija, I see light, and I hear voices, and I fear that I am mad.”In this narration, the Prophet of Allah openly admits that he fears he is insane. Such an admission raises many questions — questions that, in most cases, remain unanswered.But we must ask:Why would Allah reveal a verse calling his own prophet insane?Why didn’t Muhammad deny being called insane? The prophetic mission of Muhammad becomes highly questionable when he himself admits, “O Khadija, … I fear that I am mad.”In all other Holy Scriptures, we have never read of any prophet of the Bible admitting to being insane. Yet here we find Muhammad, the prophet of Allah, confessing it.So, why should we follow a prophet who acknowledged that he was insane? That is a fundamental question.Allah himself, in the Qur’an, instructs Muslims to ask thePeople of the Book— the Jews and the Christians — when they have doubts or questions, for they possess knowledge.Allah has already answered:Christians hold the truth and have the answers for this world.MUHAMMAD SAID:“I fear that I am mad.”Copyright © Max Shimba Ministries 2013

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
