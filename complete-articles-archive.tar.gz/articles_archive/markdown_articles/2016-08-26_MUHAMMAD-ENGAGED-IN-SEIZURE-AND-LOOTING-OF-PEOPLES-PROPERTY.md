# MUHAMMAD ENGAGED IN SEIZURE AND LOOTING OF PEOPLE’S PROPERTY

**Publication Date:** August 26, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/12/muhammad-engaged-in-seizure-and-looting.html  
**Keyword Match:** muhammad  
**Word Count:** 248  
**Archived:** 2026-01-19 18:21:47  
**Date Source:** content_regex

---

Friday, August 26, 2016MUHAMMAD ENGAGED IN SEIZURE AND LOOTING OF PEOPLE’S PROPERTYA Behavior Contrary to a Prophet’s ConductHistorical records indicate that Muhammad, along with his followers, engaged in the seizure and looting of caravans belonging to merchants and travelers. This conduct raises significant questions about the prophetic character traditionally attributed to him.According toSahih Bukhari, Volume 3, Book 37, Chapter 8, Hadith 495 (page 280), it is stated:“When Allah made the Prophet wealthy without conflict, one-fifth of the war captives’ possessions were allocated to the treasury.”Similarly,Sahih Muslim, Volume 2, Book 5, Hadith 401, Number 2348 (page 519) indicates that Muhammad’s family retained shares of the spoils, illustrating that these acts contributed to their personal wealth.The first organized seizures of people’s property by early Muslims are historically documented as theNakha’ Raid. Even during the sacred months, when fighting was traditionally suspended, Muhammad’s followers attacked caravans, killing individuals and taking the survivors as captives. Muhammad personally led the second raid atBadr, consolidating both wealth and influence.Muhammad further expanded his wealth through attacks on Jewish settlements, notablyKhaybar. He and his loyal followers seized goods, women, and other property. Historical accounts record that after the surrender of 700–1,000 Jewish men from theBanu Quraizatribe, they were executed, and their women were taken. This raises critical questions regarding the ethical and prophetic nature of such actions.The evidence challenges the conventional narrative of Muhammad as solely a spiritual leader, showing that his rise was also facilitated through warfare, conquest, and appropriation of wealth.—Shimba Theological Institute Newsletter

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
