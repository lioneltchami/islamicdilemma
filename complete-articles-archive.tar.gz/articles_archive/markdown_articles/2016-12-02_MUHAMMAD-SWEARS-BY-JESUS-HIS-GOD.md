# MUHAMMAD SWEARS BY JESUS HIS GOD

**Publication Date:** December 2, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/06/muhammad-swears-by-jesus-his-god.html  
**Keyword Match:** muhammad  
**Word Count:** 225  
**Archived:** 2025-12-04 01:03:10  
**Date Source:** content_regex

---

Friday, December 2, 2016Read the authentic hadith from Al-Bukhari:Muhammad says this in (Bukhari Hadith number 425, volume 3), the hadith narrated by Abu Huraira, the Messenger of Allah (peace be upon him) said:He said, "I swear by the One in whose hand my soul is, soon the Son of Mary will descend among you and will judge with justice."If Muhammad swears by Jesus and acknowledges that Jesus will be the one to judge, why should I follow Allah, who is not Yahweh?Why didn’t Muhammad swear by Allah?NOW, IF ONE MUST SWEAR ONLY BY ALMIGHTY GOD, WHY DID MUHAMMAD SWEAR BY JESUS?SO, JESUS IS ALMIGHTY GOD.In the hadith narrated by Abdallah bin `Umar (may Allah be pleased with him) and reported by Al-Bukhari:"إِنَّ اللَّهَ يَنْهَاكُمْ أَنْ تَحْلِفُوا بِآبَائِكُمْ ، فَمَنْ كَانَ حَالِفًا فَلْيَحْلِفْ بِاللَّهِ أو فَلْيَصْمُتْ"Its meaning: “Indeed, Allah forbids you from swearing by your fathers. Whoever has to swear, let him swear by Allah or remain silent.”NOW, READ WHERE THE PROPHET MUHAMMAD SWEARS BY JESUS:(Bukhari Hadith number 425, volume 3), the hadith narrated by Abu Huraira, the Messenger of Allah (peace be upon him) said:He said, "I swear by the One in whose hand my soul is, soon the Son of Mary will descend among you and will judge with justice."SO, MUHAMMAD KNOWS THAT JESUS IS ALMIGHTY GOD.Shalom,Dr. Maxwell Shimba,Servant of Jesus ChristShimba Theological Institute

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
