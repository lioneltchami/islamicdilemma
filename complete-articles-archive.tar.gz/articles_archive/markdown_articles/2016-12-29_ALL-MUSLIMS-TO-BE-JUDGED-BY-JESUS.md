# ALL MUSLIMS TO BE JUDGED BY JESUS

**Publication Date:** December 29, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/12/all-muslims-to-be-judged-by-jesus.html  
**Keyword Match:** muslim  
**Word Count:** 265  
**Archived:** 2026-02-07 12:30:55  
**Date Source:** content_regex

---

Thursday, December 29, 2016ALL MUSLIMS TO BE JUDGED BY JESUSFinally, Muhammad admitted that Jesus is God.Who will judge all the people of the world?The Bible answers that Jesus is the one who will judge all the people of the world, meaning Muhammad, Allah, all Muslims, and all jinn will be judged by Jesus.(Psalm 58:11)– “Surely there is a God who rules in the earth.”(Revelation 18:8)– “Therefore, her plagues will come in one day—death and mourning and famine—and she will be utterly burned with fire, for the Lord God who judges her is mighty.”It is He who will judge the whole world. “For the Father judges no one, but has given all judgment to the Son (JESUS).”(Matthew 25:31-32)– “When the Son of Man (JESUS) comes in His glory, and all the angels with Him, then He will sit on His glorious throne. All the nations will be gathered before Him, and He will separate them as a shepherd separates the sheep from the goats.”(Acts 10:42)– “He commanded us to preach to the people and testify that this is He (Jesus) whom God appointed as Judge of the living and the dead.”(Romans 2:16)– “On that day God will judge the secrets of men by Jesus Christ, according to my gospel.”(2 Timothy 4:1)– “I charge you in the presence of God and of Christ Jesus, who will judge the living and the dead, and by His appearing and His kingdom.”So why not accept Jesus, who will judge your life? Remember, the Judge is JESUS, not Allah or Muhammad.Come to Jesus.I am Max Shimba, a servant of Jesus Christ.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
