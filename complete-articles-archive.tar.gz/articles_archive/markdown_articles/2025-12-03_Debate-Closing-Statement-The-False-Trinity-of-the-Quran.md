# Debate Closing Statement: The False Trinity of the Qur’an

**Publication Date:** December 03, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/debate-closing-statement-false-trinity.html  
**Keyword Match:** allah  
**Word Count:** 319  
**Archived:** 2025-12-12 12:28:07  
**Date Source:** content_regex

---

Debate Closing Statement: The False Trinity of the Qur’anLadies and gentlemen, allow me to close with clarity.The Qur’an inSurah al-Ma’idah 5:116accuses Christians of worshiping a Trinity made of Allah, Jesus, and Mary. But let history and theology bear witness:no Christian council, no creed, no Church Father, no denomination has ever taught such a thing.The true Christian confession has always been:One God in three persons — Father, Son, and Holy Spirit.Mary is honored as the mother of Jesus in His humanity, but never as God. To claim otherwise is to misrepresent two thousand years of Christian faith.Now, here is the problem for Islam: If Allah is truly God, He should know what Christians believe. If the Qur’an is truly revelation, it should represent the Christian doctrine truthfully. But the Qur’an does not. It fabricates a false trinity and puts false words in the mouth of Jesus. That is not divine revelation; that iserror.And if the Qur’an contains error, then Allah is not all-knowing, and Muhammad is not a prophet of the true God. By contrast, the Bible tells us that God cannot lie (Titus 1:2), His Word is truth (John 17:17), and His revelation is perfect (Psalm 19:7).Therefore, the conclusion is unavoidable:The Qur’an is false, Muhammad is a false prophet, and Allah is not the God of Abraham, Isaac, and Jacob.But there is good news. The true God has revealed Himself in Jesus Christ, the eternal Word made flesh, who died for our sins and rose again. He is alive, He reigns, and He saves all who call upon His name.So I leave you with a challenge:Follow the book that misrepresents history, or follow the Savior who conquered death.Trust in a prophet who lied, or trust in the Son of God who is the Truth.As for me, I will stand with the Triune God — Father, Son, and Holy Spirit — the only true and living God, forever praised.Thank you.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
