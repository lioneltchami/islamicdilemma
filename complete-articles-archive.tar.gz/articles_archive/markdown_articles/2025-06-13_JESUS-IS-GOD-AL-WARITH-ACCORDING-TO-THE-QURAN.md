# JESUS IS GOD “AL-WARITH” ACCORDING TO THE QURAN

**Publication Date:** June 13, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/06/jesus-is-god-al-warith-according-to.html  
**Keyword Match:** quran  
**Word Count:** 473  
**Archived:** 2026-02-08 12:31:45  
**Date Source:** content_regex

---

Dear reader,Does Jesus possess the unique attributes of God according to the Quran? Let us begin our study by reading the Quran to see for ourselves if Jesus is truly God or not.One of the attributes or majesty of God according to the Quran isAl-Warith, meaningTHE INHERITOR OF ALL THINGS. This attribute, Al-Warith, is one of the 99 Names of Allah in the Quran.Does Jesus have this attribute of beingTHE INHERITOR OF ALL THINGS, “Al-Warith”? Let us first read the Quran and see if Allah possesses this attribute of Al-Warith.Surah Maryam 19:40:“So beware! Know that surely Allah is the inheritor of the entire world and everything in it, and their account is with Allah.”Allah says that He is the inheritor of all things in the Quran, which was written in the year 632 AD after Jesus. This means that Jesus was actually the first to declare these words, that He is the inheritor of all things, according to the evidence of the Bible, which came before the Quran.Let us now see if Jesus truly has this attribute of beingTHE INHERITOR OF ALL THINGS, which is the majesty of God alone according to the Quran, written 632 years after Jesus.The Holy Bible says the following about Jesus Christ:Hebrews 1:2:“But in these last days he has spoken to us by his Son, whom he appointed heir of all things, and through whom he made the universe.”In this verse, we read that Jesus is called“HEIR OF ALL THINGS,”which is the majesty/attribute of Almighty God as also testified in the Quran, Surah 19:40. Therefore, Allah and the Quran have acknowledged that Jesus is God because the Bible, which preceded the Quran by 632 years, has confirmed that Jesus is the heir of all things—and this evidence is found in the Book of Hebrews 1:2.Dear friends, this is enough evidence to prove that Jesus is God, because today we have learned that Jesus was called and claimed to beTHE INHERITOR OF ALL THINGS632 years before the Quran was written. Now, between the Bible that came before the Quran and the Quran that came after the Bible, which book will you follow? Researchers in various fields always use the earliest data to authenticate matters. And the earliest data we have about the “Inheritor of All Things” is found in the Bible and says thatTHE INHERITOR OF ALL THINGS IS JESUS.There is no debate here about the inheritance of all things, which belongs to Jesus. For He is the Son of God and was confirmed as the heir of all things 632 years before the Quran.Today I have answered the question of Muslims: “Is Jesus God?” The Quran and Allah themselves say that Jesus is God because Jesus possesses all the majesty and/or attributes of God—and one of these attributes isAL-WARITH.In His service,Dr. Maxwell ShimbaCopyright © Max Shimba Ministries 2015

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
