# Where is the copy of the Torah, the Psalms, and the Gospel that existed before the Qur’an and before the birth of Muhammad?

**Publication Date:** December 20, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/12/where-is-copy-of-torah-psalms-and.html  
**Keyword Match:** islam  
**Word Count:** 115  
**Archived:** 2025-12-14 18:19:06  
**Date Source:** content_regex

---

Tuesday, December 20, 2016THE WEAKNESS OF THE ISLAMIC RELIGIONMuslims do not have the Book of the Torah.Muslims do not have the Book of the Psalms.Muslims do not have the Book of the Gospel.If there is any Muslim who disagrees, then bring me a copy of those books that existed before the Qur’an.If you bring me a copy that Allah claims He revealed to Moses, or David, or Jesus, then today I,Max Shimba, will convert and become a Muslim.Remember, I have no time for your Qur’anic verses because the Qur’an came later.Bring me the copies of those booksbefore Muhammad was born.I WANT TO CONVERT TO ISLAM.Shalom,Dr. Max Shimba, servant of Jesus Christ, the Great God.Titus 2:13

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
