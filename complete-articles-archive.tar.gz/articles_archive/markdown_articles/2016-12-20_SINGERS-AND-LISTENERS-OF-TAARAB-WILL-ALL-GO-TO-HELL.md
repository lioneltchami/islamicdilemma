# SINGERS AND LISTENERS OF TAARAB WILL ALL GO TO HELL

**Publication Date:** December 20, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/05/singers-and-listeners-of-taarab-will.html  
**Keyword Match:** allah  
**Word Count:** 349  
**Archived:** 2026-01-23 06:23:57  
**Date Source:** content_regex

---

SINGERS AND LISTENERS OF TAARAB WILL ALL GO TO HELL“And of the people is he who buys the amusement of speech to mislead others from the way of Allah without knowledge and who takes it in ridicule. Those will have a humiliating punishment.” [Luqmaan: 6]. Ibn 'Abbaas (Radhiya Allaahu 'anhuma) also said about this verse: "It refers to songs and foolish words." [Authentic Isnaad from Shaykh Al-Albaaniy].SINGERS/LISTENERS OF MUSIC WILL BE TURNED INTO MONKEYS AND PIGSThe Prophet (peace be upon him) said: “There will be among my ummah people who will consider illegal sexual intercourse, the wearing of silk, the drinking of alcoholic drinks, and musical instruments as lawful. And some people will stay near the side of a mountain and their shepherd will come in the evening with their sheep and ask them for something, but they will say: ‘Return to us tomorrow.’ Allah will destroy them during the night and will let the mountain fall on them, and He will transform the rest of them into monkeys and pigs until the Day of Resurrection.” [Al-Bukhaari]This hadith confirms that all these sins are equally forbidden. Just as adultery and alcohol are haram, music is also haram in the same way.So, how can a Muslim see music as not being a major sin to avoid?Imaam Abu Haniyfah said: "Singing (songs, dancing) is among the major sins that a Muslim should avoid quickly." A Muslim should be more fearful of potentially facing the punishment of being transformed into monkeys or pigs for such sins, as warned in the following hadith:The Prophet (peace be upon him) said: “There will be among my ummah people who will drink alcohol, calling it by another name, and music will be played for them and female singers will sing for them. Allah will cause the earth to swallow them, and He will turn them into monkeys and pigs.” [Ibn Maajah and authenticated by Shaykh Al-Albaaniy]SORRY TO MUSLIMS BECAUSE ALLAH DOES NOT LIKE TAARAB MUSIC OR BONGO FLEVA MUSICShalom,Dr. Max Shimba, a servant of Jesus Christ, the Great God. Titus 2:13First posted on December 20, 2016

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
