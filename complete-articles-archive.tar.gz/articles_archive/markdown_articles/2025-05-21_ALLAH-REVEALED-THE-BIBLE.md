# ALLAH REVEALED THE BIBLE

**Publication Date:** May 21, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/05/allah-revealed-bible.html  
**Keyword Match:** muslim  
**Word Count:** 254  
**Archived:** 2026-02-08 01:55:03  
**Date Source:** content_regex

---

THE QUESTION OF MUSLIMS TO CHRISTIANS: WHO WAS GIVEN THE BIBLE?This is the question of Muslims, that the Bible is not the Book of God because they do not know who was given it.Today I answer them using their Quran. According to the Quran given to Muhammad, it acknowledges as follows:Surah Al-Ankabut 47And thus We have sent down to you (O Muhammad) the Book (the Qur'an). So thoseWe have giventhe Book (the Bible) will believe in it (the Qur'an), and among these (polytheists) are those who will believe in it. And they do not reject Our signs except as disbelievers.http://www.iium.edu.my/deed/quran/english/29.htmALLAH SAYS THAT HE REVEALED THE BIBLE AND GAVE IT TO THE PEOPLE OF THE BOOK.Allah acknowledges that the Bible was revealed.Allah acknowledges that He gave the Bible to the People of the Book. It means the Bible was given to more than one person.Allah says that those who reject the Bible are disbelievers.Because the Bible was given to more than one person, this means the Bible is a collection of books.QUESTION:Who were those given the Bible?Inside the Bible, there are the Torah, Psalms, and the Gospel, books that Muslims accept.In Surah 3:3, it tells us the following:"He has sent down upon you, [O Muhammad], the Book in truth, confirming what was before it. And He revealed the Torah and the Gospel."Who was given the Torah?Who was given the Psalms?Who was given the Gospel?How are the other books Allah revealed different?Muslims, answer this question.ShalomMax Shimba, a slave of Jesus Christ the Great God. Titus 2:13

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
