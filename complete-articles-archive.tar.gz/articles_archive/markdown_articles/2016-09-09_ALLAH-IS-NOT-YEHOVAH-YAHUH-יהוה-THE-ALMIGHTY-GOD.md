# ALLAH IS NOT YEHOVAH “YAHUH” (יְהוָה), THE ALMIGHTY GOD

**Publication Date:** September 9, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/12/allah-is-not-yehovah-yahuh-almighty-god.html  
**Keyword Match:** quran  
**Word Count:** 281  
**Archived:** 2026-01-28 01:08:40  
**Date Source:** content_regex

---

:Friday, September 9, 2016ALLAH SWEARS BY YEHOVAH, WHO CREATED MALE AND FEMALEALLAH IS NOT YEHOVAH “YAHUH” (יְהוָה), THE ALMIGHTY GOD(PART FIVE)Who created male and female?QURAN 92:1–3By the night when it covers,By the day when it appears,And by Him Who created the male and the female…If a person swears by someone else, is he God or a human being? And who exactly is the Creator mentioned here? Allah swears “by Him who created,” and creation is an attribute of God. Therefore, Allah Himself is not the Creator in this verse.Who is this One who created the male and the female, the One by whom the Allah of Islam swears? Continue reading… from the Holy Bible:Jeremiah 27:5“I made the earth, humankind, and the animals on the face of the earth by my great power and my outstretched arm; and I give it to anyone I please.”Here we read thatYehovah, the God of the Bible, is the One who created everything— including the male and the female— the very beings by whom the Allah of Islam swears. Therefore, Jehovah created male and female, and Allah swears by Him. Now you decide: who is truly God?Can God swear by another being? Keep learning…Hebrews 6:13“When God made His promise to Abraham, since He had no one greater by whom to swear, He swore by Himself.”Jehovah declares that there is no one greater than Himself by whom He could swear. Yet Allah in the Qur’an swears by the One who created male and female.Thus, today we understand thatthe Creator is Jehovah, and Allah swears by Jehovah, the God of the Bible and of Christians.Therefore,Allah is not the Almighty God.God bless you richly,Max Shimba© Max Shimba Ministries 2013

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
