# Scholarly Rebuttal Outline: Trinity and Mary in the Qur’an

**Publication Date:** December 03, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/scholarly-rebuttal-outline-trinity-and.html  
**Keyword Match:** allah  
**Word Count:** 260  
**Archived:** 2026-01-29 12:38:44  
**Date Source:** content_regex

---

Scholarly Rebuttal Outline: Trinity and Mary in the Qur’an1. Qur’anic ClaimSurah al-Ma’idah 5:116 suggests Christians worship a trinity ofAllah, Jesus, and Mary.This forms the basis of the Qur’an’s alleged critique of Christianity.2. Historical Christian DoctrineTrinity: One God in three persons — Father, Son, Holy Spirit (Matthew 28:19; 2 Corinthians 13:14).Mary: Blessed among women, honored asTheotokos(Mother of God in Christ’s humanity), never divine.Evidence:Nicene Creed (325 A.D.) – Father, Son, Holy Spirit. Mary absent.Athanasian Creed – Confirms Trinitarian orthodoxy.Church Fathers (Irenaeus, Tertullian, Athanasius) – No doctrine of Mary as God.Conclusion: Qur’anic claim is historically and theologically false.3. Logical/Theological AnalysisGod is truth (Titus 1:2; Numbers 23:19).If the Qur’an were revelation from God, it could not misrepresent Christian belief.Qur’an’s misrepresentation =logical impossibility for a true omniscient God.4. Implications for IslamAllah in the Qur’an:Misrepresents historical and theological facts.Demonstrates either ignorance or deception.Muhammad as prophet:Claims false revelation.Therefore cannot be a messenger of the true God (Deuteronomy 18:20–22).5. Scriptural Affirmation of TruthBible confirms:God cannot lie (Titus 1:2).God revealed Himself as Father, Son, Holy Spirit.Jesus Christ is the eternal Word and Savior (John 1:1–14).6. Debate StrategyAsk the Muslim scholar: “Have any Christians ever taught that Mary is God?”Cite historical evidence: Church councils, creeds, writings of early Church Fathers.Expose the logical flaw: Omniscient God would not misrepresent human belief.Contrast with Scripture: Highlight God’s truthfulness and Christ’s divine revelation.Conclude firmly: Qur’an misrepresents, Allah cannot be God, Muhammad cannot be true prophet, only Jesus is Savior and God.7. Optional Closing Question“If God cannot lie, how can the Qur’an claim Christians worship Mary, when history and theology clearly prove they do not?”

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
