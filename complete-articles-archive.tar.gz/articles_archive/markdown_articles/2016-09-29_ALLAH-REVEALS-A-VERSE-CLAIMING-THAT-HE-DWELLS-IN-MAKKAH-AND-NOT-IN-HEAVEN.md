# ALLAH REVEALS A VERSE CLAIMING THAT HE DWELLS IN MAKKAH AND NOT IN HEAVEN

**Publication Date:** September 29, 2016  
**Original URL:** https://www.maxshimbaministries.org/2025/12/allah-reveals-verse-claiming-that-he.html  
**Keyword Match:** muslim  
**Word Count:** 406  
**Archived:** 2025-12-08 18:21:26  
**Date Source:** content_regex

---

By Dr. Maxwell ShimbaShimba Theological InstituteThursday, September 29, 2016ALLAH REVEALS A VERSE CLAIMING THAT HE DWELLS IN MAKKAH AND NOT IN HEAVENAccording to the Qur’an, Allah acknowledges and confesses that the true God is above—dwelling in heaven. However, in order to divert the Muslims, he commands them to direct their faces toward the place wherehe himselfresides—namely, Makkah.What Does It Mean to Swear an Oath?To swear, to take an oath, or to make a solemn vow means to affirm something by invoking the Name of Almighty God, especially when the matter being sworn by lacks clear or visible evidence. The one who swears declares that the statement is as true and reliable as claimed, and therefore the hearer is expected to believe it—because the ultimate guarantor of the oath is God Himself, the only One who knows the truth or falsehood of what is hidden in the human heart.A Qur’anic Verse That Demonstrates That Allah Lives in Makkah and Not in HeavenThe following passage establishes, according to the Qur’an, that Allah resides in the city of Makkah:Surat al-Balad (Qur’an 90:1–2)translated by Sheikh Ali Muhsin Al-Barwani:“I swear by this City!”“And you are a dweller of this City.”(Source: quranitukufu.net/090.html)QUESTIONS:Why does Muhammad swear by the city of Makkah?Who is the one dwelling in the city of Makkah by whom Muhammad is swearing?The Qur’an indicates that Muhammad is swearing by Allah—the one who dwells in Makkah.After Allah “revealed” a verse claiming that He dwells in Makkah, Muhammad further emphasizes this idea in the hadith by prohibiting Muslims from looking toward heaven during prayer. Instead, he requires them to direct their faces toward Allah’s earthly dwelling.BULUGH AL-MARĀMHadith 194 – Narrated by Jabir ibn Samurah:“The Messenger of Allah said: People who raise their eyes toward the sky while in prayer must stop, otherwise their sight will not return to them.”Yet, According to the Qur’an (Surat al-Mulk 67:17), Revealed in Makkah, We Read:“Do you feel secure from Him who is in heaven…?”Contrast With the BibleThe Bible consistently affirms that the true God is above in heaven:John 11:41“So they removed the stone. Then Jesus raised His eyes upward and said, ‘Father, I thank You that You have heard Me.’”The true and living God is above—in heaven. Yet the Allah of Islam is described as dwelling in Makkah, which is why Muslims travel there to perform prayer rituals.A Loving InvitationYou are welcome to come to Jesus Christ. He loves you deeply.Max Shimba Ministries Org.September 29, 2016

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
