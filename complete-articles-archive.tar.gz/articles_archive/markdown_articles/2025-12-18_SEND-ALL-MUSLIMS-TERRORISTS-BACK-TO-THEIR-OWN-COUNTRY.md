# SEND ALL MUSLIMS TERRORISTS, BACK TO THEIR OWN COUNTRY

**Publication Date:** December 18, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/send-all-muslims-terrorists-back-to.html  
**Keyword Match:** muslim  
**Word Count:** 0  
**Archived:** 2026-01-23 12:31:21  
**Date Source:** content_regex

---



---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
