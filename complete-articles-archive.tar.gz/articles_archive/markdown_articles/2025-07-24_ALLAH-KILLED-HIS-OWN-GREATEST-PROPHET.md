# ALLAH KILLED HIS OWN GREATEST PROPHET!

**Publication Date:** July 24, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/07/allah-killed-his-own-greatest-prophet.html  
**Keyword Match:** muhammad  
**Word Count:** 213  
**Archived:** 2026-01-29 01:18:19  
**Date Source:** content_regex

---

Muhammad attacked the unsuspectingJewish settlement of Khaibar without provocation, around 629 a.d (my estimate). He killed all males and tortured Kinana, the leader before beheading him. Why? He wanted Kinana to reveal the location of their wealth.After the massacre, he had a party where he was poisoned by a Jewish woman. The poison weakened him, and he died 3 years later in 632 A.d from it's effects. This is what he told Aisha, the child bride during his slow decline and demise!Narrated `Aisha:The Prophet (ﷺ) in his ailment in which he died, used to say, "O `Aisha! I still feel the pain caused by the food I ate at Khaibar, and at this time, I feel as if my aorta is being cut from that poison."Sahih Al Bukhari 4428Earlier, Muhammad had this revelation :"And if he (Muhammad) had forged a false saying concerning Us, We surely should have seized him by his right hand (or with power and might) and then certainly should have cut off his life artery (Aorta)." Surah 69:44-46?So , there can only be one conclusion, Allah killed Muhammad. Muhammad himself said so but Muslims , as vocal as ever, deny it!Now Muslims,  either your scholars lie, Allah lied, Muhammad lied or you lie! Come on, Pick your own poison!!!

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
