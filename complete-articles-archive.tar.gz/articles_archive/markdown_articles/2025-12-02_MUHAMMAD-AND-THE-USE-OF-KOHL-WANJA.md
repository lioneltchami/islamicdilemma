# MUHAMMAD AND THE USE OF KOHL (WANJA)

**Publication Date:** December 02, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/muhammad-and-use-of-kohl-wanja.html  
**Keyword Match:** muhammad  
**Word Count:** 407  
**Archived:** 2026-01-11 01:13:58  
**Date Source:** content_regex

---

MUHAMMAD AND THE USE OF KOHL (WANJA)Many of us know that beauty products such aswanja(kohl), lipstick, and skin-lightening cosmetics are commonly used by women. But before questioning this practice, we must first understand the history of kohl and lipstick: When did their use begin? Historically, it is believed that these practices originated in the Arab world, with ancient Egyptian women being particularly skilled in applying cosmetics. This was part of a longstanding cultural tradition that carried deep significance within society.For example, among some African communities such as the Wanyamwezi, Wadigo, and Wabondei, when a girl approached puberty, she was secluded, her body covered in ash, and upon emerging the women would applywanjato her eyes. This ritual signified that the girl was now ready for marriage. A similar cultural meaning existed in the ancient Arab world.Therefore,wanjaheld great symbolic value in early societies, and although the meaning has faded in modern times, among Arab communities a woman wearing kohl and red lipstick traditionally sent a message to men: she was expressing sexual desire. Her facial lips, painted red, represented the swelling and reddening of the genital lips when a woman was sexually aroused. This signaled to men that the woman was experiencing sexual longing.Classical scientists and scholars such asDeus HansandDesmond Morris(19th-century writers) have acknowledged this symbolic connection: when a woman applies kohl and red lipstick, it mimics the appearance of the female genitalia during sexual arousal, when they become swollen and red.Although today most women wear makeup simply as beauty enhancement without implying anything sexual, during the time of Muhammad, the use of kohl and lipstickdidcarry these cultural messages—either sexual desire or readiness for marriage.Islamic sources record that Muhammad himself used kohl. InSunan Ibn Majah, Hadith No. 309, we read:“Muhammad used to carry a horn comb with which he combed his hair. He had oil, and he had a mirror in which he looked at himself, and a container of kohl (wanja) which he applied to himself at night before sleeping. He loved using fragrances…”(Description of the clothing and personal grooming of Muhammad, Section 26)According to the cultural norms of the Arabs at that time, what did it mean for Muhammad to adorn himself in this way?If kohl and lipstick symbolized sexual readiness in women, what was Muhammad’s intention in using them?This raises serious questions within Islamic tradition.Insults are a sign that one has run out of intellectual argument.Bring evidence, not abuse.This is a major theological crisis for Islam.

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
