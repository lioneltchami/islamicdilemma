# Allah Publicly Disgraces Muhammad

**Publication Date:** December 02, 2025  
**Original URL:** https://www.maxshimbaministries.org/2025/12/allah-publicly-disgraces-muhammad.html  
**Keyword Match:** muslim  
**Word Count:** 408  
**Archived:** 2025-12-20 12:24:33  
**Date Source:** content_regex

---

Allah Publicly Disgraces MuhammadBy Dr. Maxwell Shimba – Shimba Theological InstituteMuslims strongly believe that Muhammad is holy, powerful, and honored by Allah. However, as I was reading the Qur’an, I was astonished to discover that Allah speaks harshly and disgracefully to Muhammad, His so-called messenger. The Qur’an itself contains verses where Allah rebukes Muhammad openly and uses embarrassing language against him, as shown in the following passages:“You, Muhammad, will die, and your people will also die.”Surah Az-Zumar 39:30“Then on the Day of Resurrection, you will dispute before your Lord.”(Again affirming Muhammad’s mortality)Surah Az-Zumar 39:31“Say, ‘I am only a human being like you.’”Surah Al-Kahf 18:110“Ask forgiveness for your sin and for the believing men and believing women.”The Qur’an never states that Muhammad or his followers were forgiven.Surah Muhammad 47:19“You cannot guide whom you love.”Surah Al-Qasas 28:56“Even if you ask forgiveness for them seventy times, Allah will never forgive them.”Surah At-Tawbah 9:80“Why has no angel been sent down to us? Why do we not see the angels?”The Qur’an never shows Muhammad presenting an angel as proof.Surah Al-Hijr 15:6–7“O People of the Book, you are on nothing until you uphold the Torah and the Gospel…”Allah confirms that the Jews and Christians must follow their Scriptures, not Islam.Surah Al-Ma’idah 5:68“What kind of messenger is this, who eats food and walks in the markets?Why was an angel not sent down with him? Is he bewitched?”Surah Al-Furqan 25:7–8“There is none of you who will not pass over Hell; this is an irrevocable decree.”Surah Maryam 19:71“Then We will save those who feared Allah and leave the wrongdoers within it.”Surah Maryam 19:72Critical Questions1. Who are the ones saying “We will save those who fear Allah”?Muslims believe only Allah saves. Why then does Allah speak as if others share this role?2. Why does Allah send His believers into Hell—both the righteous and the sinners?If all Muslims must enter Hell first, does this not prove there is no true Islamic Heaven except Hell itself, a place entered by believers and evildoers alike?3. Why does Allah use offensive and humiliating words toward His own messenger?This is a serious theological contradiction.Throughout the Qur’an, Allah praises Isa (Jesus) far more than Muhammad. Yet the same Qur’an records Allah speaking harshly, humiliatingly, and offensively to Muhammad.In contrast, the God of the Bibleneverspeaks disgracefully about Jesus Christ.The Qur’an’s portrayal of Allah belittling Muhammad is deeply embarrassing for the Muslim community.Why does Allah disgrace Muhammad in this manner?Reflect.Question everything.Take action.—Dr. Maxwell ShimbaShimba Theological Institute

---

*This article was automatically archived from the Max Shimba Ministries blog as part of an Islam-related articles collection.*
